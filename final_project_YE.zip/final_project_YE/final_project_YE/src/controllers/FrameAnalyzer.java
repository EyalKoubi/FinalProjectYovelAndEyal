package controllers;

import entities.Frame;
import entities.VShape;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/**
 * The FrameAnalyzer class is responsible for analyzing frames from a video,
 * evaluating their focus quality, and segmenting specific regions for detailed analysis.
 * It includes methods to calculate focus scores and extract regions of interest (ROI) from frames.
 */
public class FrameAnalyzer {

    private List<Frame> finalList;    // List of selected frames
    private List<VShape> vShapeList;  // List of detected V shapes in frames
    private double cutPixelJump;         // Pixel jump for cutting regions (sides and base) for focus evaluation

    /**
     * Constructs a FrameAnalyzer with a specified pixel jump value for cutting regions.
     *
     * @param cutPixelJump the pixel jump value for cutting regions during segmentation.
     */
    public FrameAnalyzer(double cutPixelJump) {
        this.finalList = new ArrayList<>();
        this.vShapeList = new ArrayList<>();
        this.cutPixelJump = cutPixelJump;
    }

    /**
     * Evaluates the quality of a frame by calculating focus scores for the entire frame,
     * the sides of the frame, and the base. The focus scores are then stored in the frame object.
     *
     * @param frame The frame to evaluate.
     */
    public void evaluateQuality(Frame frame) {
        // Evaluate focus for the entire frame
        double generalFocus = calculateFocus(frame.getGrayscalePixels());
        frame.setGeneralFocusScore(generalFocus);

        // Segment the frame and evaluate focus for specific regions
        int[][] sidesSegment = segmentSides(frame);
        double sidesFocus = calculateFocus(sidesSegment);
        frame.setSidesFocusScore(sidesFocus);

        int[][] baseSegment = segmentBase(frame);
        double baseFocus = calculateFocus(baseSegment);
        frame.setBaseFocusScore(baseFocus);

        // Sum all focus scores for the overall quality
        double totalFocusScore = generalFocus + sidesFocus + baseFocus;
        frame.setFocusScore(totalFocusScore);
    }

    /**
     * Adds a frame to the final list of selected frames.
     *
     * @param frame The frame to add.
     */
    public void addToFinalList(Frame frame) {
        finalList.add(frame);
    }

    /**
     * Adds a detected VShape to the list of V shapes.
     *
     * @param vShape The VShape to add.
     */
    public void addToVShapeList(VShape vShape) {
        vShapeList.add(vShape);
    }

    /**
     * Returns the list of selected frames.
     *
     * @return The final list of selected frames.
     */
    public List<Frame> getFinalList() {
        return finalList;
    }

    /**
     * Returns the list of detected V shapes.
     *
     * @return The list of detected V shapes.
     */
    public List<VShape> getVShapeList() {
        return vShapeList;
    }

    /**
     * Returns the pixel jump value used for cutting regions.
     *
     * @return The pixel jump value.
     */
    public double getCutPixelJump() {
        return cutPixelJump;
    }

    /**
     * Calculates the focus score for a given array of grayscale pixels using a combination
     * of focus metrics such as squared gradient, Brenner's gradient, variance of intensities,
     * and Vollath's F4.
     *
     * @param grayscalePixels The grayscale pixels of the frame.
     * @return The weighted focus score.
     */
	public double calculateFocus(int[][] grayscalePixels) {
        double squaredGradient = calculateSquaredGradient(grayscalePixels);
        double brennersGradient = calculateBrennersGradient(grayscalePixels);
        double varianceOfIntensities = calculateVarianceOfIntensities(grayscalePixels);
        double vollathsF4 = calculateVollathsF4(grayscalePixels);
        
        double weightedFocusScore = 
        	    0.2 * squaredGradient + 
        	    0.2 * brennersGradient + 
        	    0.4 * varianceOfIntensities + 
        	    0.2 * vollathsF4;

        return weightedFocusScore;
    }

    /**
     * Segments the sides of the frame for focus evaluation.
     *
     * @param frame The frame to segment.
     * @return A 2D array representing the segmented sides of the frame.
     */
    private int[][] segmentSides(Frame frame) {
        int[][] grayscalePixels = frame.getGrayscalePixels();
        int height = grayscalePixels.length;
        int width = grayscalePixels[0].length;

        int[][] sidesSegment = new int[height][width];
        int topY = height / 4;
        int leftX = width / 4;
        int leftY = 3 * height / 4;
        int rightX = 3 * width / 4;

        for (int y = topY; y < leftY; y += cutPixelJump) {
            for (int x = leftX; x < rightX; x += cutPixelJump) {
                if (x >= leftX && x <= rightX && y >= topY && y <= leftY) {
                    sidesSegment[y][x] = grayscalePixels[y][x];
                }
            }
        }
        return sidesSegment;
    }

    /**
     * Segments the base of the frame for focus evaluation.
     *
     * @param frame The frame to segment.
     * @return A 2D array representing the segmented base of the frame.
     */
    private int[][] segmentBase(Frame frame) {
        int[][] grayscalePixels = frame.getGrayscalePixels();
        int height = grayscalePixels.length;
        int width = grayscalePixels[0].length;

        int[][] baseSegment = new int[height][width];
        int baseY = height / 2;
        int leftX = width / 4;
        int leftY = 3 * height / 4;
        int rightX = 3 * width / 4;

        for (int y = baseY; y < leftY; y += cutPixelJump) {
            for (int x = leftX; x < rightX; x += cutPixelJump) {
                if (x >= leftX && x <= rightX && y >= baseY && y <= leftY) {
                    baseSegment[y][x] = grayscalePixels[y][x];
                }
            }
        }
        return baseSegment;
    }
    
    // Helper methods for calculating various focus metrics

    /**
     * Calculates the squared gradient focus metric.
     *
     * @param grayscalePixels The grayscale pixels of the frame.
     * @return The squared gradient value.
     */
    private double calculateSquaredGradient(int[][] grayscalePixels) {
        double squaredGradient = 0.0;
        for (int x = 0; x < grayscalePixels.length - 1; x++) {
            for (int y = 0; y < grayscalePixels[0].length - 1; y++) {
                squaredGradient += Math.pow(grayscalePixels[x + 1][y] - grayscalePixels[x][y], 2);
            }
        }
        return squaredGradient;
    }

    /**
     * Calculates the Brenner's gradient focus metric.
     *
     * @param grayscalePixels The grayscale pixels of the frame.
     * @return The Brenner's gradient value.
     */
    private double calculateBrennersGradient(int[][] grayscalePixels) {
        double brennersGradient = 0.0;
        for (int x = 0; x < grayscalePixels.length - 2; x++) {
            for (int y = 0; y < grayscalePixels[0].length; y++) {
                brennersGradient += Math.pow(grayscalePixels[x + 2][y] - grayscalePixels[x][y], 2);
            }
        }
        return brennersGradient;
    }

    /**
     * Calculates the variance of intensities in a grayscale image.
     *
     * @param grayscalePixels The grayscale pixels of the frame.
     * @return The variance of intensities value.
     */
    private double calculateVarianceOfIntensities(int[][] grayscalePixels) {
        double meanIntensity = 0.0;
        int M = grayscalePixels.length;
        int N = grayscalePixels[0].length;
        for (int x = 0; x < M; x++) {
            for (int y = 0; y < N; y++) {
                meanIntensity += grayscalePixels[x][y];
            }
        }
        meanIntensity /= (M * N);

        double variance = 0.0;
        for (int x = 0; x < M; x++) {
            for (int y = 0; y < N; y++) {
                variance += Math.pow(grayscalePixels[x][y] - meanIntensity, 2);
            }
        }
        variance /= (M * N);

        return variance;
    }

    /**
     * Calculates Vollath's F4 focus metric.
     *
     * @param grayscalePixels The grayscale pixels of the frame.
     * @return The Vollath's F4 value.
     */
    private double calculateVollathsF4(int[][] grayscalePixels) {
        double vollathsF4 = 0.0;
        int M = grayscalePixels.length;
        int N = grayscalePixels[0].length;

        for (int x = 0; x < M - 1; x++) {
            for (int y = 0; y < N; y++) {
                vollathsF4 += grayscalePixels[x][y] * grayscalePixels[x + 1][y];
            }
        }
        for (int x = 0; x < M - 2; x++) {
            for (int y = 0; y < N; y++) {
                vollathsF4 -= grayscalePixels[x][y] * grayscalePixels[x + 2][y];
            }
        }

        return vollathsF4;
    }

    /**
     * Extracts the right side segment of an image based on the VShape coordinates.
     *
     * @param image The original image.
     * @param vShape The VShape containing coordinates for the right side.
     * @return The extracted right side segment as a BufferedImage.
     */
    public BufferedImage extractRightSideSegment(BufferedImage image, VShape vShape) {
    	
    	int leftX = (int) (vShape.getBaseX() - (cutPixelJump / 4));
    	int upY = (int) (vShape.getRightY() - (cutPixelJump / 2));
    	int width = (int) ((int) Math.abs(vShape.getBaseX() - vShape.getRightX()) + cutPixelJump);
    	int height = (int) ((int) Math.abs(vShape.getBaseY() - vShape.getRightY()) + cutPixelJump);
    	
    	if (leftX < 0 || leftX > image.getWidth()) leftX = 0;
    	if (upY < 0 || upY > image.getHeight()) upY = 0;
    	if (leftX + width > image.getWidth()) width = image.getWidth() - leftX;
    	if (upY + height > image.getHeight()) height = image.getHeight() - upY;
    	
        return image.getSubimage(leftX, upY, width, height);
    }

    /**
     * Extracts the left side segment of an image based on the VShape coordinates.
     *
     * @param image The original image.
     * @param vShape The VShape containing coordinates for the left side.
     * @return The extracted left side segment as a BufferedImage.
     */
    public BufferedImage extractLeftSideSegment(BufferedImage image, VShape vShape) {
    	
    	int leftX = (int) (vShape.getLeftX() - (cutPixelJump / 2));
    	int upY = (int) (vShape.getLeftY() - (cutPixelJump / 2));
    	int width = (int) ((int) Math.abs(vShape.getBaseX() - vShape.getLeftX()) + (cutPixelJump * 0.75));
    	int height = (int) ((int) Math.abs(vShape.getBaseY() - vShape.getLeftY()) + cutPixelJump);
    	
    	if (leftX < 0 || leftX > image.getWidth()) leftX = 0;
    	if (upY < 0 || upY > image.getHeight()) upY = 0;
    	if (leftX + width > image.getWidth()) width = image.getWidth() - leftX;
    	if (upY + height > image.getHeight()) height = image.getHeight() - upY;
    	
        return image.getSubimage(leftX, upY, width, height);
    }

    /**
     * Extracts the base segment of an image based on the VShape coordinates.
     *
     * @param image The original image.
     * @param vShape The VShape containing coordinates for the base.
     * @return The extracted base segment as a BufferedImage.
     */
    public BufferedImage extractBaseSegment(BufferedImage image, VShape vShape) {
    	int leftX = (int) (vShape.getLeftX() - (cutPixelJump / 2 + 150));
    	int upY = (int) (Math.max(vShape.getLeftY(),vShape.getRightY()) - (cutPixelJump));
    	int width = (int) ((int) Math.abs(vShape.getRightX() - vShape.getLeftX()) + cutPixelJump + 300);
    	int height = (int) ((int) Math.abs(vShape.getRightY() - vShape.getLeftY()) + cutPixelJump);
    	
    	if (leftX < 0 || leftX > image.getWidth()) leftX = 0;
    	if (upY < 0 || upY > image.getHeight()) upY = 0;
    	if (leftX + width > image.getWidth()) width = image.getWidth() - leftX;
    	if (upY + height > image.getHeight()) height = image.getHeight() - upY;
    	
        return image.getSubimage(leftX, upY, width, height);
    }

    /**
     * Creates a directory if it does not exist.
     *
     * @param directoryPath The path of the directory to create.
     */
    public static void createDirectoryIfNotExists(String directoryPath) {
        File directory = new File(directoryPath);
        if (!directory.exists()) {
            boolean result = directory.mkdirs();
            if (result) {
                System.out.println("Directory created: " + directoryPath);
            } else {
                System.out.println("Failed to create directory: " + directoryPath);
            }
        } else {
            System.out.println("Directory already exists: " + directoryPath);
        }
    }

    /**
     * Saves a BufferedImage to the specified file path.
     *
     * @param bi The BufferedImage to save.
     * @param filePath The file path to save the image to.
     */
    public static void saveBufferedImage(BufferedImage bi, String filePath) {
        try {
            File outputfile = new File(filePath);
            createDirectoryIfNotExists(outputfile.getParent());
            ImageIO.write(bi, "png", outputfile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Creates a deep copy of a BufferedImage.
     *
     * @param bi The BufferedImage to copy.
     * @return A deep copy of the BufferedImage.
     */
    public static BufferedImage deepCopyBufferedImage(BufferedImage bi) {
        BufferedImage copy = new BufferedImage(bi.getWidth(), bi.getHeight(), bi.getType());
        Graphics g = copy.getGraphics();
        g.drawImage(bi, 0, 0, null);
        g.dispose();
        return copy;
    }

    /**
     * Retrieves the original RGB image for a specific frame index.
     *
     * @param frameIndex The index of the frame.
     * @return The original RGB image as a BufferedImage.
     */
    public static BufferedImage getOriginalRGBImage(int frameIndex) {
        String rgbFramePath = "C:\\vids\\rgb_frames\\" + frameIndex + "_rgb.png";
        try {
            return ImageIO.read(new File(rgbFramePath));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Saves a single segmented region of a frame to a specified directory.
     *
     * @param frame The frame containing the region.
     * @param region The segmented region as a 2D array.
     * @param outputDirectory The directory to save the segmented image to.
     * @param regionIndex The index of the segmented region.
     */
    public static void saveSingleSegmentedRegion(Frame frame, int[][] region, String outputDirectory, int regionIndex) {
        File outputDir = new File(outputDirectory);
        if (!outputDir.exists()) {
            outputDir.mkdirs();
        }
        String filePath = outputDirectory + "\\frame_" + frame.getFrameNumber() + "_region_" + regionIndex + "_segmented.png";
        BufferedImage regionImage = createImageFromRegion(frame, region, regionIndex);
        try {
            ImageIO.write(regionImage, "png", new File(filePath));
            System.out.println("Saved segmented region " + regionIndex + " for frame " + frame.getFrameNumber() + " to " + filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Creates a BufferedImage from a segmented region of a frame.
     *
     * @param frame The frame containing the region.
     * @param region The segmented region as a 2D array.
     * @param regionIndex The index of the segmented region.
     * @return The BufferedImage representing the segmented region.
     */
    private static BufferedImage createImageFromRegion(Frame frame, int[][] region, int regionIndex) {
        BufferedImage regionImage = new BufferedImage(frame.getWidth(), frame.getHeight(), BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < region.length; y++) {
            for (int x = 0; x < region[y].length; x++) {
                if (region[y][x] == 1) {
                    regionImage.setRGB(x, y, Color.RED.getRGB());
                } else {
                    regionImage.setRGB(x, y, frame.getBufferedImage().getRGB(x, y));
                }
            }
        }
        return regionImage;
    }

}
