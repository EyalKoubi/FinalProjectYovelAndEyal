package controllers;

import entities.Frame;
import java.awt.image.BufferedImage;

public class FrameProcessor {

    /**
     * Converts an image to grayscale and stores the pixel values in the given frame.
     *
     * @param img   The original RGB image to be converted.
     * @param frame The frame in which the grayscale pixels will be stored.
     */
    public void convertToGrayscale(BufferedImage img, Frame frame) {
        int width = img.getWidth();
        int height = img.getHeight();
        int[][] grayscalePixels = new int[height][width];

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int rgbValue = img.getRGB(x, y);
                int red = (rgbValue >> 16) & 0xFF;
                int green = (rgbValue >> 8) & 0xFF;
                int blue = (rgbValue) & 0xFF;
                int grayscaleValue = (int) (0.3 * red + 0.59 * green + 0.11 * blue);
                grayscalePixels[y][x] = grayscaleValue;
                int grayRGB = (grayscaleValue << 16) | (grayscaleValue << 8) | grayscaleValue;
                img.setRGB(x, y, grayRGB);
            }
        }
        frame.setGrayscalePixels(grayscalePixels);
        frame.setBufferedImage(img);
    }

    /**
     * Calculates the grayscale histogram for the given frame.
     *
     * @param frame The frame for which the histogram is calculated.
     * @return An array representing the histogram of grayscale values (0-255).
     */
    public int[] calculateHistogram(Frame frame) {
        int[] histogram = new int[256];
        int[][] grayscalePixels = frame.getGrayscalePixels();

        for (int[] row : grayscalePixels) {
            for (int value : row) {
                histogram[value]++;
            }
        }
        frame.setHistogram(histogram);
        return histogram;
    }

    /**
     * Calculates the optimal threshold using Otsu's method based on the given histogram.
     *
     * @param histogram The histogram of grayscale values.
     * @return The optimal threshold for image segmentation.
     */
    public int calculateOtsuThreshold(int[] histogram) {
        int total = 0;
        for (int i = 0; i < histogram.length; i++) {
            total += histogram[i];
        }

        int sumB = 0;
        int wB = 0;
        int maxVariance = 0;
        int threshold = 0;
        int sum1 = 0;

        for (int t = 0; t < histogram.length; t++) {
            sum1 += t * histogram[t];
        }

        for (int t = 0; t < histogram.length; t++) {
            wB += histogram[t];
            if (wB == 0) continue;

            int wF = total - wB;
            if (wF == 0) break;

            sumB += t * histogram[t];

            int mB = sumB / wB;
            int mF = (sum1 - sumB) / wF;

            int variance = wB * wF * (mB - mF) * (mB - mF);
            if (variance > maxVariance) {
                maxVariance = variance;
                threshold = t;
            }
        }
        return threshold;
    }

    /**
     * Applies a binary threshold to an image, converting it to black and white based on the threshold value.
     *
     * @param img       The grayscale image to apply the threshold to.
     * @param threshold The threshold value used for binarization.
     * @return The binary (black and white) image resulting from the threshold application.
     */
    public BufferedImage applyThreshold(BufferedImage img, int threshold) {
        int width = img.getWidth();
        int height = img.getHeight();
        BufferedImage thresholdedImg = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_BINARY);

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int rgb = img.getRGB(x, y);
                int gray = (rgb >> 16) & 0xFF;
                int binaryValue = gray > threshold ? 255 : 0;
                int binaryRGB = (binaryValue << 16) | (binaryValue << 8) | binaryValue;
                thresholdedImg.setRGB(x, y, binaryRGB);
            }
        }
        return thresholdedImg;
    }
}
