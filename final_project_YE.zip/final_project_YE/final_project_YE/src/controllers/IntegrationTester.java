package controllers;

import entities.Frame;
import entities.Video;
import entities.VShape;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import javax.imageio.ImageIO;

public class IntegrationTester {

	/**
     * Main method to test the integration of various components such as frame extraction, triangle detection,
     * motion estimation, and focus evaluation from a video.
     *
     * @param args The command-line arguments (not used).
     */
    public static void main(String[] args) {
        String videoPath = "C:\\vids\\Data\\112.mp4";
        Video video = new Video(videoPath, null, 30, 0);
        List<Frame> frames = VideoToFrames.divideIntoFrames(video);
        List<Integer> detectedFrameIndices = new ArrayList<>();

        if (frames != null && !frames.isEmpty()) {
            FrameProcessor frameProcessor = new FrameProcessor();
            TriangleDetector triangleDetector = new TriangleDetector(3.0, 0.3, 1); // Adjust leastSquaresThreshold as needed
            MotionEstimator motionEstimator = new MotionEstimator(55.0); // Set the similarity threshold here
            FrameAnalyzer focusAnalyzer = new FrameAnalyzer(130.0); // Adjust the cut pixel jump as needed

            // Test with varying parameters
            double threshold = 0.5358;
            int jump = 1;

            String intermediateDir = "C:\\vids\\intermediate";
            String triangleDetectedDir = "C:\\vids\\TriangleDetectedFrames";
            String rightSideDir = "C:\\vids\\right_side_of_triangle";
            String leftSideDir = "C:\\vids\\left_side_of_triangle";
            String baseDir = "C:\\vids\\base_of_triangle";
            String focusOutputDir = "C:\\vids\\MostFocusedFrame";

            FrameAnalyzer.createDirectoryIfNotExists(intermediateDir);
            FrameAnalyzer.createDirectoryIfNotExists(triangleDetectedDir);
            FrameAnalyzer.createDirectoryIfNotExists(rightSideDir);
            FrameAnalyzer.createDirectoryIfNotExists(leftSideDir);
            FrameAnalyzer.createDirectoryIfNotExists(baseDir);
            FrameAnalyzer.createDirectoryIfNotExists(focusOutputDir);

            int frameCount = frames.size();
            double bestGeneralFocusScore = 0;
            double bestSidesFocusScore = 0;
            double bestBaseFocusScore = 0;
            VShape bestVShapeSides = null;
            VShape bestVShapeBase = null;
            int bestGeneralFocusFrameIndex = -1;
            int bestSidesFocusFrameIndex = -1;
            int bestBaseFocusFrameIndex = -1;
            int i = 0;

            while (i < frameCount - 1) {
                Frame frame = frames.get(i);

                // Save grayscale image
                String grayscalePath = intermediateDir + "\\frame_" + frame.getFrameNumber() + "_grayscale.png";
                FrameAnalyzer.saveBufferedImage(frame.getBufferedImage(), grayscalePath);

                // Calculate histogram and Otsu threshold
                int[] histogram = frameProcessor.calculateHistogram(frame);
                int otsuThreshold = frameProcessor.calculateOtsuThreshold(histogram);

                // Apply threshold and save thresholded image
                BufferedImage thresholdedImage = frameProcessor.applyThreshold(frame.getBufferedImage(), otsuThreshold);
                String thresholdedPath = intermediateDir + "\\frame_" + frame.getFrameNumber() + "_thresholded.png";
                FrameAnalyzer.saveBufferedImage(thresholdedImage, thresholdedPath);

                RegionSegmenter regionSegmenter = new RegionSegmenter(threshold, jump); // Initialize regionSegmenter here
                List<int[][]> segmentedRegions = regionSegmenter.segmentRegions(frame, otsuThreshold);
                String segmentedRegionsDir = "C:\\vids\\segmented_" + threshold + "_" + jump;
                FrameAnalyzer.createDirectoryIfNotExists(segmentedRegionsDir);

                int regionIndex = 0;
                for (int[][] segmentedRegion : segmentedRegions) {
                    if (TriangleDetector.hasPotentialForThroatOpening(segmentedRegion)) {
                        FrameAnalyzer.saveSingleSegmentedRegion(frame, segmentedRegion, segmentedRegionsDir, regionIndex);
                        regionIndex++;
                    }

                    // Detect V-shape triangle in the segmented regions
                    VShape vShape = triangleDetector.detectBestVShape(segmentedRegion, frame.getFrameNumber(), regionIndex);
                    if (vShape != null) {
                        BufferedImage frameImage = FrameAnalyzer.deepCopyBufferedImage(frame.getBufferedImage());  // Create a copy to draw on
                        TriangleDetector.drawTriangle(frameImage, vShape);
                        String triangleDetectedPath = triangleDetectedDir + "\\frame_" + frame.getFrameNumber() + "_triangle_detected.png";
                        FrameAnalyzer.saveBufferedImage(frameImage, triangleDetectedPath);

                        // שמירת האינדקס של הפריים שזוהה בו משולש
                        detectedFrameIndices.add(i);

                        // Check for consistent frames
                        int consistentFrameIndex = i + 1;
                        while (consistentFrameIndex < frameCount && motionEstimator.areFramesSimilar(frame, frames.get(consistentFrameIndex), vShape)) {
                            consistentFrameIndex++;
                        }
                        
                        int beforeIndex = i;

                        // Add consistent frames to the output
                        for (int j = i + 1; j < consistentFrameIndex; j++) {
                            BufferedImage nextFrameImage = FrameAnalyzer.deepCopyBufferedImage(frames.get(j).getBufferedImage());
                            String nextFramePath = triangleDetectedDir + "\\frame_" + frames.get(j).getFrameNumber() + "_triangle_detected.png";
                            FrameAnalyzer.saveBufferedImage(nextFrameImage, nextFramePath);
                            i = j;
                            frame = frames.get(i);
                            frameImage = FrameAnalyzer.deepCopyBufferedImage(frame.getBufferedImage());  // Create a copy to draw on
                            TriangleDetector.drawTriangle(frameImage, vShape);
                            triangleDetectedPath = triangleDetectedDir + "\\frame_" + frame.getFrameNumber() + "_triangle_detected.png";
                            FrameAnalyzer.saveBufferedImage(frameImage, triangleDetectedPath);
                        }

                        // Extract and save right side and base segments
                        BufferedImage rightSideSegment = focusAnalyzer.extractRightSideSegment(frame.getBufferedImage(), vShape);
                        String rightSidePath = rightSideDir + "\\frame_" + frame.getFrameNumber() + "_right_side.png";
                        FrameAnalyzer.saveBufferedImage(rightSideSegment, rightSidePath);

                        BufferedImage leftSideSegment = focusAnalyzer.extractLeftSideSegment(frame.getBufferedImage(), vShape); // New method call for left side segment
                        String leftSidePath = leftSideDir + "\\frame_" + frame.getFrameNumber() + "_left_side.png";
                        FrameAnalyzer.saveBufferedImage(leftSideSegment, leftSidePath);

                        BufferedImage baseSegment = focusAnalyzer.extractBaseSegment(frame.getBufferedImage(), vShape);
                        String basePath = baseDir + "\\frame_" + frame.getFrameNumber() + "_base.png";
                        FrameAnalyzer.saveBufferedImage(baseSegment, basePath);

                        // Calculate focus score
                        focusAnalyzer.evaluateQuality(frame); // Use the original RGB frame for focus analysis
                        double generalFocusScore = frame.getGeneralFocusScore();
                        double sidesFocusScore = frame.getSidesFocusScore();
                        double baseFocusScore = frame.getBaseFocusScore();

                        // Update best frames based on focus
                        if (generalFocusScore > bestGeneralFocusScore) {
                            bestGeneralFocusScore = generalFocusScore;
                            bestGeneralFocusFrameIndex = beforeIndex; // Use the index of the frame in the list
                        }
                        if (sidesFocusScore > bestSidesFocusScore) {
                            bestSidesFocusScore = sidesFocusScore;
                            bestSidesFocusFrameIndex = beforeIndex; // Use the index of the frame in the list
                            bestVShapeSides = vShape;
                        }
                        if (baseFocusScore > bestBaseFocusScore) {
                            bestBaseFocusScore = baseFocusScore;
                            bestBaseFocusFrameIndex = beforeIndex; // Use the index of the frame in the list
                            bestVShapeBase = vShape;
                        }

                        break; // Found a valid triangle, move to the next frame
                    }
                }
                i++;
            }

            // Save the best focus frames
            if (bestGeneralFocusFrameIndex != -1) {
                try {
                    String bestGeneralFocusFramePath = focusOutputDir + "\\best_general_focus_frame.png";
                    BufferedImage bestGeneralFocusImage = FrameAnalyzer.getOriginalRGBImage(bestGeneralFocusFrameIndex); // פונקציה שמחזירה את התמונה המקורית לפי האינדקס
                    ImageIO.write(bestGeneralFocusImage, "png", new File(bestGeneralFocusFramePath));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (bestSidesFocusFrameIndex != -1) {
                try {
                    String bestRightSideFocusFramePath = focusOutputDir + "\\best_right_side_focus_frame.png";
                    String bestLeftSideFocusFramePath = focusOutputDir + "\\best_left_side_focus_frame.png";
                    BufferedImage bestSidesFocusImage = FrameAnalyzer.getOriginalRGBImage(bestSidesFocusFrameIndex); // פונקציה שמחזירה את התמונה המקורית לפי האינדקס
                    BufferedImage bestLeftSideFocusSegment = focusAnalyzer.extractRightSideSegment(bestSidesFocusImage, bestVShapeSides);
                    BufferedImage bestRightSideFocusSegment = focusAnalyzer.extractLeftSideSegment(bestSidesFocusImage, bestVShapeSides);
                    ImageIO.write(bestLeftSideFocusSegment, "png", new File(bestRightSideFocusFramePath));
                    ImageIO.write(bestRightSideFocusSegment, "png", new File(bestLeftSideFocusFramePath));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (bestBaseFocusFrameIndex != -1) {
                try {
                    String bestBaseFocusFramePath = focusOutputDir + "\\best_base_focus_frame.png";
                    BufferedImage bestBaseFocusImage = FrameAnalyzer.getOriginalRGBImage(bestBaseFocusFrameIndex); // פונקציה שמחזירה את התמונה המקורית לפי האינדקס
                    BufferedImage bestBaseFocusSegment = focusAnalyzer.extractBaseSegment(bestBaseFocusImage, bestVShapeBase);
                    ImageIO.write(bestBaseFocusSegment, "png", new File(bestBaseFocusFramePath));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
