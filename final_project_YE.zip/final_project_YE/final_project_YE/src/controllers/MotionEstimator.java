package controllers;

import entities.Frame;
import entities.VShape;
import java.util.ArrayList;
import java.util.List;

/**
 * The MotionEstimator class is responsible for estimating the similarity between frames based on the detected V-shape and
 * calculating block-based differences using Mean Squared Error (MSE) and Mean Absolute Difference (MAD).
 */

public class MotionEstimator {

	// The search radius used for block matching in the next frame
    private static final int SEARCH_RADIUS = 10;
    // The similarity threshold for determining if frames are similar
    private final double similarityThreshold;

    /**
     * Constructs a new MotionEstimator with the specified similarity threshold.
     *
     * @param similarityThreshold The threshold for frame similarity.
     */
    public MotionEstimator(double similarityThreshold) {
        this.similarityThreshold = similarityThreshold;
    }

    /**
     * Determines if two frames are similar based on the detected V-shape and the similarity threshold.
     *
     * @param currentFrame   The current frame being analyzed.
     * @param nextFrame      The next frame to compare.
     * @param currentVShape  The detected V-shape in the current frame.
     * @return true if the frames are similar; false otherwise.
     */
    public boolean areFramesSimilar(Frame currentFrame, Frame nextFrame, VShape currentVShape) {
        // Extract the boundary blocks of the V shape in the current frame
        List<int[]> currentBoundaryBlocks = getBoundaryBlocks(currentVShape);

        double totalDifference = 0;
        int blockCount = 0;

        // Loop through the boundary blocks and find the matching blocks in the next frame
        for (int[] block : currentBoundaryBlocks) {
            int[] bestMatch = findMatchingBlock(currentFrame, nextFrame, block);
            if (bestMatch == null) {
                System.out.println("No matching block found for block: (" + block[0] + ", " + block[1] + ")");
                return false; // No matching block found, frames are not similar
            }

            totalDifference += calculateCombinedDifference(currentFrame, nextFrame, block, bestMatch);
            blockCount++;
        }

        double averageDifference = totalDifference / blockCount;
        System.out.println("Average combined difference between frames: " + averageDifference);

        return averageDifference < similarityThreshold;
    }

    /**
     * Extracts the boundary blocks of the detected V-shape.
     *
     * @param vShape The detected V-shape in the current frame.
     * @return A list of boundary block coordinates.
     */
    private List<int[]> getBoundaryBlocks(VShape vShape) {
        List<int[]> boundaryBlocks = new ArrayList<>();

        // Add the points along the boundary of the V shape
        boundaryBlocks.add(new int[]{vShape.getBaseX(), vShape.getBaseY()});
        boundaryBlocks.add(new int[]{vShape.getLeftX(), vShape.getLeftY()});
        boundaryBlocks.add(new int[]{vShape.getRightX(), vShape.getRightY()});

        return boundaryBlocks;
    }

    /**
     * Finds the matching block in the next frame for the given block in the current frame.
     *
     * @param currentFrame The current frame being analyzed.
     * @param nextFrame    The next frame to compare.
     * @param block        The current block's coordinates.
     * @return The coordinates of the best matching block in the next frame.
     */
    private int[] findMatchingBlock(Frame currentFrame, Frame nextFrame, int[] block) {
        double minDifference = Double.MAX_VALUE;
        int[] bestMatch = null;

        for (int y = Math.max(0, block[1] - SEARCH_RADIUS); y < Math.min(nextFrame.getHeight(), block[1] + SEARCH_RADIUS); y++) {
            for (int x = Math.max(0, block[0] - SEARCH_RADIUS); x < Math.min(nextFrame.getWidth(), block[0] + SEARCH_RADIUS); x++) {
                double difference = calculateCombinedDifference(currentFrame, nextFrame, block, new int[]{x, y});
                if (difference < minDifference) {
                    minDifference = difference;
                    bestMatch = new int[]{x, y};
                }
            }
        }

        return bestMatch;
    }

    /**
     * Calculates the combined difference between the current and reference blocks using MSE and MAD.
     *
     * @param currentFrame   The current frame being analyzed.
     * @param nextFrame      The next frame to compare.
     * @param currentBlock   The current block's coordinates.
     * @param referenceBlock The reference block's coordinates.
     * @return The combined difference between the two blocks.
     */
    private double calculateCombinedDifference(Frame currentFrame, Frame nextFrame, int[] currentBlock, int[] referenceBlock) {
        double mse = calculateMSE(currentFrame, nextFrame, currentBlock, referenceBlock);
        double mad = calculateMAD(currentFrame, nextFrame, currentBlock, referenceBlock);

        // Adjust weights as needed
        double weightMSE = 0.5;
        double weightMAD = 0.5;

        return (weightMSE * mse) + (weightMAD * mad);
    }

    /**
     * Calculates the Mean Squared Error (MSE) between the current and reference blocks.
     *
     * @param currentFrame   The current frame being analyzed.
     * @param nextFrame      The next frame to compare.
     * @param currentBlock   The current block's coordinates.
     * @param referenceBlock The reference block's coordinates.
     * @return The MSE between the two blocks.
     */
    private double calculateMSE(Frame currentFrame, Frame nextFrame, int[] currentBlock, int[] referenceBlock) {
        int[][] currentPixels = currentFrame.getGrayscalePixels();
        int[][] referencePixels = nextFrame.getGrayscalePixels();
        int N = 8; // Assuming block size of 8x8

        double mse = 0.0;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                int currentPixel = currentPixels[currentBlock[1] + i][currentBlock[0] + j];
                int referencePixel = referencePixels[referenceBlock[1] + i][referenceBlock[0] + j];
                mse += Math.pow(currentPixel - referencePixel, 2);
            }
        }
        mse /= (N * N);
        return mse;
    }

    /**
     * Calculates the Mean Absolute Difference (MAD) between the current and reference blocks.
     *
     * @param currentFrame   The current frame being analyzed.
     * @param nextFrame      The next frame to compare.
     * @param currentBlock   The current block's coordinates.
     * @param referenceBlock The reference block's coordinates.
     * @return The MAD between the two blocks.
     */
    private double calculateMAD(Frame currentFrame, Frame nextFrame, int[] currentBlock, int[] referenceBlock) {
        int[][] currentPixels = currentFrame.getGrayscalePixels();
        int[][] referencePixels = nextFrame.getGrayscalePixels();
        int N = 8; // Assuming block size of 8x8

        double mad = 0.0;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                int currentPixel = currentPixels[currentBlock[1] + i][currentBlock[0] + j];
                int referencePixel = referencePixels[referenceBlock[1] + i][referenceBlock[0] + j];
                mad += Math.abs(currentPixel - referencePixel);
            }
        }
        mad /= (N * N);
        return mad;
    }
}
