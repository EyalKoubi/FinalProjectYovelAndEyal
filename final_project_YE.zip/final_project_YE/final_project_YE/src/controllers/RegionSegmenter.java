package controllers;

import entities.Frame;

import java.util.*;

/**
 * The RegionSegmenter class is responsible for segmenting regions in a given frame 
 * based on a segmentation threshold and pixel jump tolerance. It utilizes region growing 
 * and other techniques to detect regions with potential for throat openings.
 */
public class RegionSegmenter {

    private double segmentationThreshold;  // Threshold for segmentation, multiplied by the Otsu threshold
    private int tolerancePixelJump;        // Tolerance for pixel jump when growing regions

    /**
     * Constructs a new RegionSegmenter with specified segmentation threshold and pixel jump tolerance.
     *
     * @param segmentationThreshold The threshold for segmentation.
     * @param tolerancePixelJump     The tolerance for pixel jump when growing regions.
     */
    public RegionSegmenter(double segmentationThreshold, int tolerancePixelJump) {
        this.segmentationThreshold = segmentationThreshold;
        this.tolerancePixelJump = tolerancePixelJump;
    }

    /**
     * Segments regions in the provided frame based on the Otsu threshold and the segmentation threshold.
     * 
     * @param frame        The frame to segment.
     * @param otsuThreshold The Otsu threshold for segmentation.
     * @return A list of segmented regions that have potential for throat openings.
     */
    public List<int[][]> segmentRegions(Frame frame, int otsuThreshold) {
        int width = frame.getWidth();
        int height = frame.getHeight();
        int[][] grayscalePixels = frame.getGrayscalePixels();
        boolean[][] visited = new boolean[height][width];
        List<int[][]> regions = new ArrayList<>();

        otsuThreshold *= segmentationThreshold;

        int[] seed = findDarkestPixel(grayscalePixels, visited, otsuThreshold);
        while (seed != null) {
            int[][] region = new int[height][width];
            System.out.println("Found seed at (" + seed[0] + ", " + seed[1] + ")");
            growRegion(grayscalePixels, visited, region, seed, otsuThreshold);
            if (hasPotentialForThroatOpening(region)) {
                regions.add(region);
            }
            seed = findDarkestPixel(grayscalePixels, visited, otsuThreshold);
        }

        return regions;
    }

    /**
     * Grows a region starting from a seed pixel and adds neighboring pixels based on the Otsu threshold.
     * 
     * @param grayscalePixels The grayscale pixel values of the frame.
     * @param visited         A 2D boolean array indicating whether a pixel has been visited.
     * @param region          The region being grown.
     * @param seed            The seed pixel to start the region growing.
     * @param otsuThreshold   The Otsu threshold for pixel inclusion in the region.
     */
    private void growRegion(int[][] grayscalePixels, boolean[][] visited, int[][] region, int[] seed, int otsuThreshold) {
        Queue<int[]> queue = new LinkedList<>();
        queue.add(seed);
        visited[seed[1]][seed[0]] = true;

        while (!queue.isEmpty()) {
            int[] current = queue.poll();
            int x = current[0];
            int y = current[1];

            int pixelValue = grayscalePixels[y][x];
            if (pixelValue <= otsuThreshold || isWithinTolerance(grayscalePixels, x, y, otsuThreshold)) {
                region[y][x] = 1;
                addNeighborsToQueue(queue, x, y, visited);
            }
        }
    }

    /**
     * Finds the darkest pixel in the frame that hasn't been visited yet and is below the Otsu threshold.
     * 
     * @param grayscalePixels The grayscale pixel values of the frame.
     * @param visited         A 2D boolean array indicating whether a pixel has been visited.
     * @param otsuThreshold   The Otsu threshold for pixel inclusion in the region.
     * @return The coordinates of the darkest pixel, or null if no such pixel is found.
     */
    private int[] findDarkestPixel(int[][] grayscalePixels, boolean[][] visited, int otsuThreshold) {
        int minIntensity = 256;
        int[] darkestPixel = null;

        for (int y = 0; y < grayscalePixels.length; y++) {
            for (int x = 0; x < grayscalePixels[y].length; x++) {
                if (!visited[y][x] && grayscalePixels[y][x] <= otsuThreshold) {
                    int pixelValue = grayscalePixels[y][x];
                    if (pixelValue < minIntensity) {
                        minIntensity = pixelValue;
                        darkestPixel = new int[]{x, y};
                    }
                }
            }
        }
        if (darkestPixel != null) {
            System.out.println("Darkest pixel found at (" + darkestPixel[0] + ", " + darkestPixel[1] + ") with intensity " + minIntensity);
        }
        return darkestPixel;
    }

    /**
     * Adds the neighboring pixels of a given pixel to the queue for region growing.
     * 
     * @param queue    The queue used for region growing.
     * @param x        The x-coordinate of the current pixel.
     * @param y        The y-coordinate of the current pixel.
     * @param visited  A 2D boolean array indicating whether a pixel has been visited.
     */
    private void addNeighborsToQueue(Queue<int[]> queue, int x, int y, boolean[][] visited) {
        int[][] neighbors = {
            {x - tolerancePixelJump, y},
            {x + tolerancePixelJump, y},
            {x, y - tolerancePixelJump},
            {x, y + tolerancePixelJump},
            {x - tolerancePixelJump, y - tolerancePixelJump},
            {x + tolerancePixelJump, y - tolerancePixelJump},
            {x - tolerancePixelJump, y + tolerancePixelJump},
            {x + tolerancePixelJump, y + tolerancePixelJump}
        };

        for (int[] neighbor : neighbors) {
            int nx = neighbor[0];
            int ny = neighbor[1];
            if (nx >= 0 && nx < visited[0].length && ny >= 0 && ny < visited.length && !visited[ny][nx]) {
                queue.add(neighbor);
                visited[ny][nx] = true;
            }
        }
    }

    /**
     * Checks if a pixel is within the tolerance of the Otsu threshold.
     * 
     * @param grayscalePixels The grayscale pixel values of the frame.
     * @param x               The x-coordinate of the pixel.
     * @param y               The y-coordinate of the pixel.
     * @param otsuThreshold   The Otsu threshold for pixel inclusion in the region.
     * @return true if the pixel is within the tolerance; false otherwise.
     */
    private boolean isWithinTolerance(int[][] grayscalePixels, int x, int y, int otsuThreshold) {
        int toleranceCount = 0;
        Queue<int[]> queue = new LinkedList<>();
        queue.add(new int[]{x, y});

        while (!queue.isEmpty() && toleranceCount <= tolerancePixelJump) {
            int[] pixel = queue.poll();
            int px = pixel[0];
            int py = pixel[1];

            if (grayscalePixels[py][px] <= otsuThreshold) {
                return true;
            } else {
                toleranceCount++;
                addNeighborPixelsToQueue(queue, px, py, grayscalePixels);
            }
        }

        return toleranceCount <= tolerancePixelJump;
    }

    /**
     * Adds the neighboring pixels of a given pixel to the queue for tolerance checking.
     * 
     * @param queue           The queue used for tolerance checking.
     * @param x               The x-coordinate of the current pixel.
     * @param y               The y-coordinate of the current pixel.
     * @param grayscalePixels The grayscale pixel values of the frame.
     */
    private void addNeighborPixelsToQueue(Queue<int[]> queue, int x, int y, int[][] grayscalePixels) {
        int[][] neighbors = {
            {x - 1, y},
            {x + 1, y},
            {x, y - 1},
            {x, y + 1},
            {x - 1, y - 1},
            {x + 1, y - 1},
            {x - 1, y + 1},
            {x + 1, y + 1}
        };

        for (int[] neighbor : neighbors) {
            int nx = neighbor[0];
            int ny = neighbor[1];
            if (nx >= 0 && nx < grayscalePixels[0].length && ny >= 0 && ny < grayscalePixels.length) {
                queue.add(neighbor);
            }
        }
    }

    /**
     * Determines if a segmented region has potential for containing a throat opening.
     * The check is based on the size and aspect ratio of the region.
     * 
     * @param region The segmented region.
     * @return true if the region has potential for a throat opening; false otherwise.
     */
    private boolean hasPotentialForThroatOpening(int[][] region) {
        int minRegionSize = 100;  // Adjust this value as necessary
        int count = 0;
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, maxX = 0, maxY = 0;

        for (int y = 0; y < region.length; y++) {
            for (int x = 0; x < region[y].length; x++) {
                if (region[y][x] == 1) {
                    count++;
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
            }
        }

        int width = maxX - minX + 1;
        int height = maxY - minY + 1;
        double aspectRatio = (double) width / height;

        // Check size and aspect ratio for a triangle-like shape
        return count >= minRegionSize && aspectRatio > 0.5 && aspectRatio < 2.0;
    }
}
