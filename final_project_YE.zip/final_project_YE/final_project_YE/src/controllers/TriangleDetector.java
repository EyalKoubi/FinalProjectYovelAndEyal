package controllers;

import entities.VShape;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import javax.imageio.ImageIO;

/**
 * The TriangleDetector class is responsible for detecting V-shape (triangle) regions 
 * in segmented images, calculating metrics like area and perimeter, and drawing the triangle.
 */
public class TriangleDetector {

    private static final double MIN_AREA = 20000.0;
    private static final double MAX_AREA = 90000.0;
    
    private double leastSquaresThreshold;
    private double middle;
    private int numExtremePoints;
    private BufferedWriter rssWriter; // writer for RSS results

    /**
     * Constructs a new TriangleDetector with the specified least squares threshold, 
     * middle value for point distance comparison, and number of extreme points to consider.
     *
     * @param leastSquaresThreshold The threshold for least squares score.
     * @param middle                The middle value used to compare point distances from the center.
     * @param numExtremePoints      The number of extreme points to consider when detecting the triangle.
     */
    public TriangleDetector(double leastSquaresThreshold, double middle, int numExtremePoints) {
        this.leastSquaresThreshold = leastSquaresThreshold;
        this.middle = middle;
        this.numExtremePoints = numExtremePoints;
        try {
            rssWriter = new BufferedWriter(new FileWriter("C:\\vids\\RSS.txt", true));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Detects the best possible V-shape (triangle) in the provided segmented region.
     *
     * @param region       The segmented region to search for a triangle.
     * @param frameNumber  The frame number of the current frame.
     * @param regionIndex  The index of the segmented region within the frame.
     * @return A VShape object representing the best triangle found, or null if no valid triangle is found.
     */
    public VShape detectBestVShape(int[][] region, int frameNumber, int regionIndex) {
        System.out.println("Starting triangle detection...");
        List<int[]> edgePoints = findEdgePoints(region);
        if (edgePoints.size() < 3) {
            System.out.println("Not enough edge points to form a triangle.");
            return null; // Not enough points to form a triangle
        }

        System.out.println("Found " + edgePoints.size() + " edge points.");

        List<int[]> rightMostPoints = findRightMostPoints(edgePoints, numExtremePoints);
        List<int[]> bottomMostPoints = findBottomMostPoints(edgePoints, numExtremePoints);
        List<int[]> leftMostPoints = findLeftMostPoints(edgePoints, numExtremePoints);

        if (rightMostPoints.isEmpty() || bottomMostPoints.isEmpty() || leftMostPoints.isEmpty()) {
            System.out.println("Not enough points to form a triangle.");
            return null; // Not enough points to form a triangle
        }

        VShape bestVShape = null;
        double bestScore = Double.MAX_VALUE;

        for (int[] rightMostPoint : rightMostPoints) {
            for (int[] bottomMostPoint : bottomMostPoints) {
                for (int[] leftMostPoint : leftMostPoints) {
                    if (isPointNearCenter(rightMostPoint, region[0].length, region.length) && isPointNearCenter(leftMostPoint, region[0].length, region.length) && isPointNearCenter(bottomMostPoint, region[0].length, region.length)) {
                        VShape vShape = new VShape(bottomMostPoint, leftMostPoint, rightMostPoint);
                        double area = calculateTriangleArea(vShape);
                        if (area <= MAX_AREA && area >= MIN_AREA) {
                            double score = calculateLeastSquaresScore(region, vShape);
                            if (score < bestScore) {
                                bestScore = score;
                                bestVShape = vShape;
                            }
                        }
                    }
                }
            }
        }

        if (bestVShape != null && bestScore < leastSquaresThreshold) {
            System.out.println("Found a valid triangle with least squares score: " + bestScore);
            try {
                rssWriter.write("Frame: " + frameNumber + ", Region: " + regionIndex + ", Best RSS: " + bestScore + "\n");
                rssWriter.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
        	bestVShape = null;
            System.out.println("No valid triangle found.");
        }

        return bestVShape;
    }

    /**
     * Determines if a given point is near the center of the image.
     *
     * @param point  The point to check.
     * @param width  The width of the image.
     * @param height The height of the image.
     * @return true if the point is near the center, false otherwise.
     */
    private boolean isPointNearCenter(int[] point, int width, int height) {
        double centerX = width / 2.0;
        double centerY = height / 2.0;
        double distanceFromCenterX = Math.abs(point[0] - centerX);
        double distanceFromCenterY = Math.abs(point[1] - centerY);
        return distanceFromCenterX / width < middle && distanceFromCenterY / height < middle;
    }

    /**
     * Finds all edge points in a segmented region.
     *
     * @param region The segmented region.
     * @return A list of edge points.
     */
    private List<int[]> findEdgePoints(int[][] region) {
        List<int[]> edgePoints = new ArrayList<>();
        int height = region.length;
        int width = region[0].length;

        for (int y = 1; y < height - 1; y++) {
            for (int x = 1; x < width - 1; x++) {
                if (region[y][x] == 1 && isEdgePoint(region, x, y)) {
                    edgePoints.add(new int[]{x, y});
                }
            }
        }

        return edgePoints;
    }

    /**
     * Determines if a pixel is an edge point by checking its neighbors.
     *
     * @param region The segmented region.
     * @param x      The x-coordinate of the pixel.
     * @param y      The y-coordinate of the pixel.
     * @return true if the pixel is an edge point, false otherwise.
     */
    private boolean isEdgePoint(int[][] region, int x, int y) {
        for (int dy = -1; dy <= 1; dy++) {
            for (int dx = -1; dx <= 1; dx++) {
                if (dx != 0 || dy != 0) {
                    if (isValidPoint(region, x + dx, y + dy) && region[y + dy][x + dx] == 0) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Finds the right-most points from the list of edge points.
     *
     * @param edgePoints The list of edge points.
     * @param numPoints  The number of right-most points to return.
     * @return A list of right-most points.
     */
    private List<int[]> findRightMostPoints(List<int[]> edgePoints, int numPoints) {
        List<int[]> rightMostPoints = new ArrayList<>(edgePoints);
        rightMostPoints.sort(Comparator.comparingInt(point -> -point[0]));
        return rightMostPoints.subList(0, Math.min(numPoints, rightMostPoints.size()));
    }

    /**
     * Finds the bottom-most points from the list of edge points.
     *
     * @param edgePoints The list of edge points.
     * @param numPoints  The number of bottom-most points to return.
     * @return A list of bottom-most points.
     */
    private List<int[]> findBottomMostPoints(List<int[]> edgePoints, int numPoints) {
        List<int[]> bottomMostPoints = new ArrayList<>(edgePoints);
        bottomMostPoints.sort(Comparator.comparingInt(point -> -point[1]));
        return bottomMostPoints.subList(0, Math.min(numPoints, bottomMostPoints.size()));
    }

    /**
     * Finds the left-most points from the list of edge points.
     *
     * @param edgePoints The list of edge points.
     * @param numPoints  The number of left-most points to return.
     * @return A list of left-most points.
     */
    private List<int[]> findLeftMostPoints(List<int[]> edgePoints, int numPoints) {
        List<int[]> leftMostPoints = new ArrayList<>(edgePoints);
        leftMostPoints.sort(Comparator.comparingInt(point -> point[0]));
        return leftMostPoints.subList(0, Math.min(numPoints, leftMostPoints.size()));
    }

    /**
     * Validates if the point (x, y) is within the bounds of the region.
     *
     * @param region The segmented region.
     * @param x      The x-coordinate.
     * @param y      The y-coordinate.
     * @return true if the point is valid, false otherwise.
     */
    private boolean isValidPoint(int[][] region, int x, int y) {
        return x >= 0 && x < region[0].length && y >= 0 && y < region.length;
    }

    /**
     * Calculates the least squares score for the triangle defined by the given VShape.
     *
     * @param region The segmented region.
     * @param vShape The VShape (triangle) for which the score is calculated.
     * @return The least squares score.
     */
    private double calculateLeastSquaresScore(int[][] region, VShape vShape) {
        double score = 0.0;
        score += calculateLeastSquaresForLine(region, vShape.getBaseX(), vShape.getBaseY(), vShape.getLeftX(), vShape.getLeftY());
        score += calculateLeastSquaresForLine(region, vShape.getLeftX(), vShape.getLeftY(), vShape.getRightX(), vShape.getRightY());
        score += calculateLeastSquaresForLine(region, vShape.getRightX(), vShape.getRightY(), vShape.getBaseX(), vShape.getBaseY());
        return score;
    }

    /**
     * Calculates the least squares score for the line defined by two points (x1, y1) and (x2, y2).
     *
     * @param region The segmented region.
     * @param x1     The x-coordinate of the first point.
     * @param y1     The y-coordinate of the first point.
     * @param x2     The x-coordinate of the second point.
     * @param y2     The y-coordinate of the second point.
     * @return The least squares score for the line.
     */
    private double calculateLeastSquaresForLine(int[][] region, int x1, int y1, int x2, int y2) {
        double sumOfSquares = 0.0;
        int n = 0;

        int dx = Math.abs(x2 - x1);
        int dy = Math.abs(y2 - y1);

        int sx = x1 < x2 ? 1 : -1;
        int sy = y1 < y2 ? 1 : -1;
        int err = dx - dy;

        while (true) {
            if (isValidPoint(region, x1, y1)) {
                sumOfSquares += Math.pow(region[y1][x1], 2);
                n++;
            }

            if (x1 == x2 && y1 == y2) break;
            int e2 = 2 * err;
            if (e2 > -dy) {
                err -= dy;
                x1 += sx;
            }
            if (e2 < dx) {
                err += dx;
                y1 += sy;
            }
        }

        return n > 0 ? sumOfSquares / n : Double.MAX_VALUE;
    }

    /**
     * Draws a triangle on the given image based on the points of the VShape.
     *
     * @param image  The image on which to draw the triangle.
     * @param vShape The VShape defining the triangle to be drawn.
     */
    public static void drawTriangle(BufferedImage image, VShape vShape) {

    	BufferedImage coloredImage = new BufferedImage(image.getWidth(), image.getHeight(), BufferedImage.TYPE_INT_RGB);

        Graphics2D g = coloredImage.createGraphics();
        g.drawImage(image, 0, 0, null);

        g.setColor(Color.RED);
        g.setStroke(new BasicStroke(32));

        g.drawLine(vShape.getBaseX(), vShape.getBaseY(), vShape.getLeftX(), vShape.getLeftY());
        g.drawLine(vShape.getLeftX(), vShape.getLeftY(), vShape.getRightX(), vShape.getRightY());
        g.drawLine(vShape.getRightX(), vShape.getRightY(), vShape.getBaseX(), vShape.getBaseY());

        g.dispose();

        Graphics2D g2 = image.createGraphics();
        g2.drawImage(coloredImage, 0, 0, null);
        g2.dispose();
    }

    /**
     * Saves the image with the detected triangle and outputs the triangle's area and perimeter.
     *
     * @param image     The image containing the triangle.
     * @param vShape    The detected VShape.
     * @param outputPath The path to save the image.
     */
    public void saveTriangleDetectedImage(BufferedImage image, VShape vShape, String outputPath) {
        drawTriangle(image, vShape);
        try {
            File outputfile = new File(outputPath);
            System.out.println("Saving image to: " + outputfile.getAbsolutePath());
            ImageIO.write(image, "png", outputfile);

            // Calculate and print the area and perimeter
            double area = calculateTriangleArea(vShape);
            double perimeter = calculateTrianglePerimeter(vShape);
            System.out.println("Triangle area: " + area);
            System.out.println("Triangle perimeter: " + perimeter);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Prints the details (area and perimeter) of the triangle defined by the VShape.
     *
     * @param vShape The VShape defining the triangle.
     */
    public void printTriangleDetails(VShape vShape) {
        double area = calculateTriangleArea(vShape);
        double perimeter = calculateTrianglePerimeter(vShape);
        System.out.println("Triangle area: " + area);
        System.out.println("Triangle perimeter: " + perimeter);
    }

    /**
     * Calculates the area of the triangle defined by the VShape.
     *
     * @param vShape The VShape defining the triangle.
     * @return The area of the triangle.
     */
    private double calculateTriangleArea(VShape vShape) {
        int x1 = vShape.getBaseX();
        int y1 = vShape.getBaseY();
        int x2 = vShape.getLeftX();
        int y2 = vShape.getLeftY();
        int x3 = vShape.getRightX();
        int y3 = vShape.getRightY();
        return Math.abs((x1*(y2 - y3) + x2*(y3 - y1) + x3*(y1 - y2)) / 2.0);
    }

    /**
     * Calculates the perimeter of the triangle defined by the VShape.
     *
     * @param vShape The VShape defining the triangle.
     * @return The perimeter of the triangle.
     */
    private double calculateTrianglePerimeter(VShape vShape) {
        int x1 = vShape.getBaseX();
        int y1 = vShape.getBaseY();
        int x2 = vShape.getLeftX();
        int y2 = vShape.getLeftY();
        int x3 = vShape.getRightX();
        int y3 = vShape.getRightY();
        return distance(x1, y1, x2, y2) + distance(x2, y2, x3, y3) + distance(x3, y3, x1, y1);
    }

    /**
     * Calculates the Euclidean distance between two points.
     *
     * @param x1 The x-coordinate of the first point.
     * @param y1 The y-coordinate of the first point.
     * @param x2 The x-coordinate of the second point.
     * @param y2 The y-coordinate of the second point.
     * @return The Euclidean distance between the two points.
     */
    private double distance(int x1, int y1, int x2, int y2) {
        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    }
    
    /**
     * Determines whether the segmented region has potential for throat opening based on pixel count.
     *
     * @param segmentedRegion The segmented region to evaluate.
     * @return true if the region has potential, false otherwise.
     */
    public static boolean hasPotentialForThroatOpening(int[][] segmentedRegion) {
        int count = 0;
        for (int y = 0; y < segmentedRegion.length; y++) {
            for (int x = 0; x < segmentedRegion[y].length; x++) {
                if (segmentedRegion[y][x] == 1) {
                    count++;
                }
            }
        }
        return count > (segmentedRegion.length * segmentedRegion[0].length * 0.05); // Example threshold
    }
}
