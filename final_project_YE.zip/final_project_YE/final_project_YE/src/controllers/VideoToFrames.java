package controllers;

import entities.Frame;
import entities.Video;
import org.bytedeco.javacv.FFmpegFrameGrabber;
import org.bytedeco.javacv.Java2DFrameConverter;
import org.bytedeco.javacv.FFmpegLogCallback;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;

/**
 * This class provides functionality for extracting frames from a video and processing them.
 */
public class VideoToFrames {

    public static final int WIDTH = 800;
    public static final int HEIGHT = 800;
    public static final int CROPX = 560;
    public static final int CROPY = 143;
    public static final String OUTPUT_DIRECTORY = "C:\\vids\\frames";
    public static final String RGB_OUTPUT_DIRECTORY = "C:\\vids\\rgb_frames";

    /**
     * Deletes all files and subfolders in the given folder.
     *
     * @param folder The folder to be deleted.
     */
    public static void deleteFolder(File folder) {
        File[] files = folder.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.isDirectory()) {
                    deleteFolder(f);
                } else {
                    f.delete();
                }
            }
        }
    }

    /**
     * Divides the video into frames and processes them (converts them to grayscale, saves the images).
     *
     * @param vid The video to be divided into frames.
     * @return A list of frames extracted and processed from the video.
     */
    @SuppressWarnings("resource")
	public static List<Frame> divideIntoFrames(Video vid) {
        String vidPath = vid.getFilePath();
		FFmpegFrameGrabber frameGrabber = new FFmpegFrameGrabber(vidPath);

        frameGrabber.setFormat("mp4");
        FFmpegLogCallback.set();

        List<Frame> frames = new ArrayList<>();
        FrameProcessor frameProcessor = new FrameProcessor();

        try {
            frameGrabber.start();
            int indexLoad = 0;
            int frameSkipInterval = 3;
            int frameCounter = 0;
            File outputDirectory = new File(OUTPUT_DIRECTORY);
            File rgbOutputDirectory = new File(RGB_OUTPUT_DIRECTORY);
            if (!outputDirectory.exists()) {
                if (!outputDirectory.mkdir()) return null;
            } else {
                deleteFolder(outputDirectory);
            }
            if (!rgbOutputDirectory.exists()) {
                if (!rgbOutputDirectory.mkdir()) return null;
            } else {
                deleteFolder(rgbOutputDirectory);
            }
            String outputPath = outputDirectory.getPath();
            String rgbOutputPath = rgbOutputDirectory.getPath();

            org.bytedeco.javacv.Frame grabbedFrame;
            Java2DFrameConverter converter = new Java2DFrameConverter();
            while ((grabbedFrame = frameGrabber.grab()) != null) {
                if (frameCounter % frameSkipInterval == 0) {
                    BufferedImage bi = converter.convert(grabbedFrame);
                    if (bi != null) {
                        BufferedImage croppedImage = cropImage(bi, CROPX, CROPY, WIDTH, HEIGHT);
                        
                        // Save RGB image before converting to grayscale
                        String rgbFilePath = rgbOutputPath + "\\" + indexLoad + "_rgb.png";
                        saveBufferedImage(croppedImage, rgbFilePath);

                        BufferedImage grayImage = new BufferedImage(croppedImage.getWidth(), croppedImage.getHeight(), BufferedImage.TYPE_BYTE_GRAY);
                        Graphics g = grayImage.getGraphics();
                        g.drawImage(croppedImage, 0, 0, null);
                        g.dispose();
                        Frame frame = new Frame(indexLoad, grayImage);

                        frameProcessor.convertToGrayscale(grayImage, frame);

                        String filePath = outputPath + "\\" + indexLoad + ".png";
                        saveBufferedImage(grayImage, filePath);

                        frames.add(frame);
                        vid.addFrame(frame);

                        indexLoad++;
                    }
                }
                frameCounter++;
            }
            frameGrabber.stop();
        } catch (Exception e) {
            e.printStackTrace();
        }
        vid.setFrames(frames);
        return frames;
    }

    /**
     * Crops the input image to the specified region.
     *
     * @param img The original image.
     * @param cropX The X-coordinate of the crop's starting point.
     * @param cropY The Y-coordinate of the crop's starting point.
     * @param width The width of the cropped image.
     * @param height The height of the cropped image.
     * @return The cropped BufferedImage.
     */
    private static BufferedImage cropImage(BufferedImage img, int cropX, int cropY, int width, int height) {
        return img.getSubimage(cropX, cropY, width, height);
    }

    /**
     * Saves the given BufferedImage to a specified file path in PNG format.
     *
     * @param bi The BufferedImage to be saved.
     * @param filePath The file path where the image will be saved.
     */
    public static void saveBufferedImage(BufferedImage bi, String filePath) {
        try {
            File outputfile = new File(filePath);
            ImageIO.write(bi, "png", outputfile);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
