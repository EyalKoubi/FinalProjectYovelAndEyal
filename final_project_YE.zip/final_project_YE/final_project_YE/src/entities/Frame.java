package entities;

import java.awt.image.BufferedImage;
import java.util.List;

/**
 * The Frame class represents a single video frame and contains information
 * about its pixels, dimensions, grayscale values, focus scores, and more.
 */
public class Frame {
    private int frameNumber;           // Frame number in the video sequence         
    private List<Pixel> pixels;        // List of pixels in the frame      
    private int width;                 // Width of the frame               
    private int height;                // Height of the frame              
    private int[][] grayscalePixels;   // 2D array of grayscale pixel values 
    private int[] histogram;           // Histogram of grayscale values         
    private double focusScore;         // Overall focus score of the frame       
    private double generalFocusScore;  // Focus score for the general area of the frame 
    private double sidesFocusScore;    // Focus score for the sides of the frame   
    private double baseFocusScore;     // Focus score for the base of the frame    
    private BufferedImage bufferedImage; // BufferedImage representing the frame 

    /**
     * Constructor for the Frame class.
     *
     * @param frameNumber    The number of the frame in the video sequence.
     * @param bufferedImage  The BufferedImage representing the frame.
     */
    public Frame(int frameNumber, BufferedImage bufferedImage) {
        this.frameNumber = frameNumber;
        this.bufferedImage = bufferedImage;
        this.width = bufferedImage.getWidth();
        this.height = bufferedImage.getHeight();
    }
    
    // Getters and setters for all fields

    /**
     * Gets the frame number.
     *
     * @return The frame number.
     */
    public int getFrameNumber() {
        return frameNumber;
    }

    /**
     * Sets the frame number.
     *
     * @param frameNumber The new frame number.
     */
    public void setFrameNumber(int frameNumber) {
        this.frameNumber = frameNumber;
    }

    /**
     * Gets the list of pixels in the frame.
     *
     * @return The list of pixels.
     */
    public List<Pixel> getPixels() {
        return pixels;
    }

    /**
     * Sets the list of pixels for the frame.
     *
     * @param pixels The list of pixels.
     */
    public void setPixels(List<Pixel> pixels) {
        this.pixels = pixels;
    }

    /**
     * Gets the width of the frame.
     *
     * @return The width of the frame.
     */
    public int getWidth() {
        return width;
    }

    /**
     * Sets the width of the frame.
     *
     * @param width The new width.
     */
    public void setWidth(int width) {
        this.width = width;
    }

    /**
     * Gets the height of the frame.
     *
     * @return The height of the frame.
     */
    public int getHeight() {
        return height;
    }

    /**
     * Sets the height of the frame.
     *
     * @param height The new height.
     */
    public void setHeight(int height) {
        this.height = height;
    }

    /**
     * Gets the 2D array of grayscale pixel values.
     *
     * @return The grayscale pixel values.
     */
    public int[][] getGrayscalePixels() {
        return grayscalePixels;
    }

    /**
     * Sets the 2D array of grayscale pixel values.
     *
     * @param grayscalePixels The grayscale pixel values.
     */
    public void setGrayscalePixels(int[][] grayscalePixels) {
        this.grayscalePixels = grayscalePixels;
    }

    /**
     * Gets the histogram of grayscale values.
     *
     * @return The histogram of grayscale values.
     */
    public int[] getHistogram() {
        return histogram;
    }

    /**
     * Sets the histogram of grayscale values.
     *
     * @param histogram The grayscale histogram.
     */
    public void setHistogram(int[] histogram) {
        this.histogram = histogram;
    }

    /**
     * Gets the overall focus score of the frame.
     *
     * @return The focus score.
     */
    public double getFocusScore() {
        return focusScore;
    }

    /**
     * Sets the overall focus score of the frame.
     *
     * @param focusScore The new focus score.
     */
    public void setFocusScore(double focusScore) {
        this.focusScore = focusScore;
    }

    /**
     * Gets the general focus score of the frame.
     *
     * @return The general focus score.
     */
    public double getGeneralFocusScore() {
        return generalFocusScore;
    }

    /**
     * Sets the general focus score of the frame.
     *
     * @param generalFocusScore The new general focus score.
     */
    public void setGeneralFocusScore(double generalFocusScore) {
        this.generalFocusScore = generalFocusScore;
    }

    /**
     * Gets the sides focus score of the frame.
     *
     * @return The sides focus score.
     */
    public double getSidesFocusScore() {
        return sidesFocusScore;
    }

    /**
     * Sets the sides focus score of the frame.
     *
     * @param sidesFocusScore The new sides focus score.
     */
    public void setSidesFocusScore(double sidesFocusScore) {
        this.sidesFocusScore = sidesFocusScore;
    }

    /**
     * Gets the base focus score of the frame.
     *
     * @return The base focus score.
     */
    public double getBaseFocusScore() {
        return baseFocusScore;
    }

    /**
     * Sets the base focus score of the frame.
     *
     * @param baseFocusScore The new base focus score.
     */
    public void setBaseFocusScore(double baseFocusScore) {
        this.baseFocusScore = baseFocusScore;
    }

    /**
     * Gets the BufferedImage representing the frame.
     *
     * @return The BufferedImage.
     */
    public BufferedImage getBufferedImage() {
        return bufferedImage;
    }

    /**
     * Sets the BufferedImage representing the frame.
     *
     * @param bufferedImage The new BufferedImage.
     */
    public void setBufferedImage(BufferedImage bufferedImage) {
        this.bufferedImage = bufferedImage;
    }
}
