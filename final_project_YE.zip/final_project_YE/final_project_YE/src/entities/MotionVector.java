package entities;

/**
 * Represents a motion vector, which tracks the movement of a block in an image by storing 
 * the starting coordinates and the changes in the X and Y directions.
 */
public class MotionVector {

    private int startX;   // Starting X coordinate of the block
    private int startY;   // Starting Y coordinate of the block
    private int deltaX;   // Change in X coordinate (movement)
    private int deltaY;   // Change in Y coordinate (movement)

    /**
     * Constructs a MotionVector with specified start coordinates and movement in the X and Y directions.
     *
     * @param startX the starting X coordinate of the block
     * @param startY the starting Y coordinate of the block
     * @param deltaX the change in the X coordinate (movement)
     * @param deltaY the change in the Y coordinate (movement)
     */
    public MotionVector(int startX, int startY, int deltaX, int deltaY) {
        this.startX = startX;
        this.startY = startY;
        this.deltaX = deltaX;
        this.deltaY = deltaY;
    }

    /**
     * Constructs a MotionVector with default values of zero for all coordinates and movement.
     */
    public MotionVector() {
        this.startX = 0;
        this.startY = 0;
        this.deltaX = 0;
        this.deltaY = 0;
    }

    /**
     * Gets the starting X coordinate of the block.
     *
     * @return the starting X coordinate
     */
    public int getStartX() {
        return startX;
    }

    /**
     * Sets the starting X coordinate of the block.
     *
     * @param startX the starting X coordinate to set
     */
    public void setStartX(int startX) {
        this.startX = startX;
    }

    /**
     * Gets the starting Y coordinate of the block.
     *
     * @return the starting Y coordinate
     */
    public int getStartY() {
        return startY;
    }

    /**
     * Sets the starting Y coordinate of the block.
     *
     * @param startY the starting Y coordinate to set
     */
    public void setStartY(int startY) {
        this.startY = startY;
    }

    /**
     * Gets the change in the X coordinate (movement).
     *
     * @return the change in X coordinate
     */
    public int getDeltaX() {
        return deltaX;
    }

    /**
     * Sets the change in the X coordinate (movement).
     *
     * @param deltaX the change in X coordinate to set
     */
    public void setDeltaX(int deltaX) {
        this.deltaX = deltaX;
    }

    /**
     * Gets the change in the Y coordinate (movement).
     *
     * @return the change in Y coordinate
     */
    public int getDeltaY() {
        return deltaY;
    }

    /**
     * Sets the change in the Y coordinate (movement).
     *
     * @param deltaY the change in Y coordinate to set
     */
    public void setDeltaY(int deltaY) {
        this.deltaY = deltaY;
    }

    /**
     * Calculates the magnitude of the motion vector, representing the overall distance of movement.
     *
     * @return the magnitude of the motion vector
     */
    public double getMagnitude() {
        return Math.sqrt(deltaX * deltaX + deltaY * deltaY);
    }
}
