package entities;

/**
 * Represents a pixel in an image with coordinates (X, Y) and an associated grayscale value.
 */
public class Pixel {

    private int coordX; // The X coordinate of the pixel
    private int coordY; // The Y coordinate of the pixel
    private int value;  // The grayscale value of the pixel

    /**
     * Constructs a Pixel object with specified coordinates and grayscale value.
     *
     * @param coordX the X coordinate of the pixel
     * @param coordY the Y coordinate of the pixel
     * @param value the grayscale value of the pixel
     */
    public Pixel(int coordX, int coordY, int value) {
        this.coordX = coordX;
        this.coordY = coordY;
        this.value = value;
    }

    /**
     * Constructs a Pixel object with default values of zero for coordinates and grayscale value.
     */
    public Pixel() {
        this.coordX = 0;
        this.coordY = 0;
        this.value = 0;
    }

    /**
     * Gets the X coordinate of the pixel.
     *
     * @return the X coordinate
     */
    public int getCoordX() {
        return coordX;
    }

    /**
     * Sets the X coordinate of the pixel.
     *
     * @param coordX the X coordinate to set
     */
    public void setCoordX(int coordX) {
        this.coordX = coordX;
    }

    /**
     * Gets the Y coordinate of the pixel.
     *
     * @return the Y coordinate
     */
    public int getCoordY() {
        return coordY;
    }

    /**
     * Sets the Y coordinate of the pixel.
     *
     * @param coordY the Y coordinate to set
     */
    public void setCoordY(int coordY) {
        this.coordY = coordY;
    }

    /**
     * Gets the grayscale value of the pixel.
     *
     * @return the grayscale value
     */
    public int getValue() {
        return value;
    }

    /**
     * Sets the grayscale value of the pixel.
     *
     * @param value the grayscale value to set
     */
    public void setValue(int value) {
        this.value = value;
    }
}
