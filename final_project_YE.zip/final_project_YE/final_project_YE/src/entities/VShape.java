package entities;

/**
 * Represents a V-shaped geometric figure with coordinates for the base, left, and right sides.
 */
public class VShape {
    private int baseX;   // X coordinate of the base of the V
    private int baseY;   // Y coordinate of the base of the V
    private int leftX;   // X coordinate of the left side of the V
    private int leftY;   // Y coordinate of the left side of the V
    private int rightX;  // X coordinate of the right side of the V
    private int rightY;  // Y coordinate of the right side of the V

    /**
     * Constructs a VShape object using arrays for the base, left, and right points.
     *
     * @param basePoint  the coordinates of the base point (x, y)
     * @param leftPoint  the coordinates of the left point (x, y)
     * @param rightPoint the coordinates of the right point (x, y)
     */
    public VShape(int[] basePoint, int[] leftPoint, int[] rightPoint) {
        this.baseX = basePoint[0];
        this.baseY = basePoint[1];
        this.leftX = leftPoint[0];
        this.leftY = leftPoint[1];
        this.rightX = rightPoint[0];
        this.rightY = rightPoint[1];
    }

    /**
     * Constructs a VShape object with individual coordinates for the base, left, and right points.
     *
     * @param baseX  the X coordinate of the base
     * @param baseY  the Y coordinate of the base
     * @param leftX  the X coordinate of the left side
     * @param leftY  the Y coordinate of the left side
     * @param rightX the X coordinate of the right side
     * @param rightY the Y coordinate of the right side
     */
    public VShape(int baseX, int baseY, int leftX, int leftY, int rightX, int rightY) {
        this.baseX = baseX;
        this.baseY = baseY;
        this.leftX = leftX;
        this.leftY = leftY;
        this.rightX = rightX;
        this.rightY = rightY;
    }

    /**
     * Constructs a VShape object with default values for all points (0, 0).
     */
    public VShape() {
        this(0, 0, 0, 0, 0, 0);
    }

    /**
     * Gets the X coordinate of the base.
     *
     * @return the X coordinate of the base
     */
    public int getBaseX() {
        return baseX;
    }
    
    /**
     * Sets the X coordinate of the base.
     *
     * @param baseX the X coordinate to set for the base
     */
    public void setBaseX(int baseX) {
        this.baseX = baseX;
    }

    /**
     * Gets the Y coordinate of the base.
     *
     * @return the Y coordinate of the base
     */
    public int getBaseY() {
        return baseY;
    }

    /**
     * Sets the Y coordinate of the base.
     *
     * @param baseY the Y coordinate to set for the base
     */
    public void setBaseY(int baseY) {
        this.baseY = baseY;
    }

    /**
     * Gets the X coordinate of the left side of the V.
     *
     * @return the X coordinate of the left side
     */
    public int getLeftX() {
        return leftX;
    }

    /**
     * Sets the X coordinate of the left side of the V.
     *
     * @param leftX the X coordinate to set for the left side
     */
    public void setLeftX(int leftX) {
        this.leftX = leftX;
    }

    /**
     * Gets the Y coordinate of the left side of the V.
     *
     * @return the Y coordinate of the left side
     */
    public int getLeftY() {
        return leftY;
    }

    /**
     * Sets the Y coordinate of the left side of the V.
     *
     * @param leftY the Y coordinate to set for the left side
     */
    public void setLeftY(int leftY) {
        this.leftY = leftY;
    }

    /**
     * Gets the X coordinate of the right side of the V.
     *
     * @return the X coordinate of the right side
     */
    public int getRightX() {
        return rightX;
    }

    /**
     * Sets the X coordinate of the right side of the V.
     *
     * @param rightX the X coordinate to set for the right side
     */
    public void setRightX(int rightX) {
        this.rightX = rightX;
    }

    /**
     * Gets the Y coordinate of the right side of the V.
     *
     * @return the Y coordinate of the right side
     */
    public int getRightY() {
        return rightY;
    }

    /**
     * Sets the Y coordinate of the right side of the V.
     *
     * @param rightY the Y coordinate to set for the right side
     */
    public void setRightY(int rightY) {
        this.rightY = rightY;
    }
}
