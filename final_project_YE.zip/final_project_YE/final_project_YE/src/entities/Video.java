package entities;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a video file and its associated properties such as file path, frames, frame rate, and total number of frames.
 */
public class Video {

    private String filePath;     // Path to the video file
    private List<Frame> frames;  // List of frames in the video
    private int frameRate;       // Frame rate of the video
    private int totalFrames;     // Total number of frames in the video

    /**
     * Constructs a Video object with the specified file path, list of frames, frame rate, and total number of frames.
     * If the list of frames is null, an empty list is initialized.
     *
     * @param filePath   the file path of the video
     * @param frames     the list of frames in the video
     * @param frameRate  the frame rate of the video
     * @param totalFrames the total number of frames in the video
     */
    public Video(String filePath, List<Frame> frames, int frameRate, int totalFrames) {
        this.filePath = filePath;
        this.frames = frames != null ? frames : new ArrayList<>(); // Initialize frames if null
        this.frameRate = frameRate;
        this.totalFrames = totalFrames;
    }

    /**
     * Constructs a Video object with default values. The file path is set to an empty string, the frames list is initialized,
     * and both the frame rate and total frames are set to zero.
     */
    public Video() {
        this.filePath = "";
        this.frames = new ArrayList<>(); // Initialize the frames list
        this.frameRate = 0;
        this.totalFrames = 0;
    }

    /**
     * Gets the file path of the video.
     *
     * @return the file path of the video
     */
    public String getFilePath() {
        return filePath;
    }
    
    /**
     * Sets the file path of the video.
     *
     * @param filePath the file path to set
     */
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
    
    /**
     * Gets the list of frames in the video.
     *
     * @return the list of frames in the video
     */
    public List<Frame> getFrames() {
        return frames;
    }

    /**
     * Sets the list of frames in the video. If the list is null, an empty list is initialized.
     *
     * @param frames the list of frames to set
     */
    public void setFrames(List<Frame> frames) {
        this.frames = frames != null ? frames : new ArrayList<>(); // Ensure frames list is not null
    }

    /**
     * Gets the frame rate of the video.
     *
     * @return the frame rate of the video
     */
    public int getFrameRate() {
        return frameRate;
    }

    /**
     * Sets the frame rate of the video.
     *
     * @param frameRate the frame rate to set
     */
    public void setFrameRate(int frameRate) {
        this.frameRate = frameRate;
    }

    /**
     * Gets the total number of frames in the video.
     *
     * @return the total number of frames in the video
     */
    public int getTotalFrames() {
        return totalFrames;
    }

    /**
     * Sets the total number of frames in the video.
     *
     * @param totalFrames the total number of frames to set
     */
    public void setTotalFrames(int totalFrames) {
        this.totalFrames = totalFrames;
    }

    /**
     * Gets a specific frame at the given index in the video.
     *
     * @param index the index of the frame to retrieve
     * @return the frame at the specified index
     */
    public Frame getFrameAt(int index) {
        return frames.get(index);
    }

    /**
     * Adds a frame to the list of frames in the video.
     *
     * @param frame the frame to add
     */
    public void addFrame(Frame frame) {
        if (this.frames == null) {
            this.frames = new ArrayList<>(); // Initialize the list if it's null
        }
        this.frames.add(frame);
    }
}
