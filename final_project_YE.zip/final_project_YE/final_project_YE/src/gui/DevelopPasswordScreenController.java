package gui;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Controller for the password input screen in the GUI. Handles password visibility toggle, 
 * password validation, and screen transitions.
 */
public class DevelopPasswordScreenController {

    @FXML
    private PasswordField passwordField;  // Input field for password (hidden)

    @FXML
    private TextField passwordFieldVisible;  // Input field for password (visible)

    @FXML
    private Button togglePasswordVisibility;  // Button to toggle password visibility
    
    @FXML
    private ImageView eyeIcon;  // Icon for showing/hiding password

    @FXML
    private Button insertButton;  // Button to submit the password

    @FXML
    private Button backButton;  // Button to navigate back
    
    @FXML
    private Label badMessageToUser;  // Label to display a message when the password is incorrect

    private boolean isPasswordVisible = false;  // Flag to track password visibility state

    /**
     * Initializes the controller after its root element has been completely processed.
     * Sets up the password visibility toggle and binds the visible and hidden password fields.
     * Also sets up event handling for the Enter key in the password field.
     */
    @FXML
    private void initialize() {
        badMessageToUser.setVisible(false);
        badMessageToUser.setText("Wrong password. Please try again!");

        passwordFieldVisible.textProperty().bindBidirectional(passwordField.textProperty());
        eyeIcon.setImage(new Image(getClass().getResourceAsStream("hide.png")));

        Platform.runLater(() -> {
            Stage stage = (Stage) passwordField.getScene().getWindow();
            stage.sizeToScene();
        });

        passwordField.setOnKeyPressed(event -> {
            switch (event.getCode()) {
                case ENTER:
                    handleInsertButtonAction();
                    break;
                default:
                    break;
            }
        });
    }

    /**
     * Toggles the visibility of the password field. Switches between displaying the password
     * as plain text and as hidden characters. Also changes the eye icon to indicate visibility status.
     */
    @FXML
    private void togglePasswordField() {
        isPasswordVisible = !isPasswordVisible;
        if (isPasswordVisible) {
            passwordField.setVisible(false);
            passwordField.setManaged(false);
            passwordFieldVisible.setVisible(true);
            passwordFieldVisible.setManaged(true);
            eyeIcon.setImage(new Image(getClass().getResourceAsStream("view.png"))); // עין עם קו חוצה
        } else {
            passwordField.setVisible(true);
            passwordField.setManaged(true);
            passwordFieldVisible.setVisible(false);
            passwordFieldVisible.setManaged(false);
            eyeIcon.setImage(new Image(getClass().getResourceAsStream("hide.png"))); // עין רגילה
        }
    }

    /**
     * Handles the action when the "Insert" button is clicked or when Enter is pressed.
     * Checks if the entered password is correct and transitions to the settings screen if successful.
     * If the password is incorrect, displays an error message.
     */
    @FXML
    private void handleInsertButtonAction() {
        if (passwordField.getText().equals("ReactIsKing")) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("SettingsScreen.fxml"));
                Parent root = loader.load();

                Stage stage = (Stage) insertButton.getScene().getWindow();
                stage.close();
                
                Stage mainStage = new Stage();
                mainStage.setScene(new Scene(root));
                mainStage.setWidth(565);
                mainStage.setHeight(530);
                mainStage.show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            badMessageToUser.setVisible(true);
        }
    }

    /**
     * Handles the action when the "Back" button is clicked.
     * Transitions back to the main screen by loading it and closing the current window.
     */
    @FXML
    private void handleBackButtonAction() {
        try {
        	
            FXMLLoader loader = new FXMLLoader(getClass().getResource("mainScreen.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.close();
            Stage newStage = new Stage();
            newStage.setScene(new Scene(root));
            newStage.setWidth(565);
            newStage.setHeight(530);
            newStage.show();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
