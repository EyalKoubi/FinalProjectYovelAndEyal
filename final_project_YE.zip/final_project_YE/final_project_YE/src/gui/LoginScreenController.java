package gui;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Controller for the login screen in the GUI. Handles user authentication, 
 * password visibility toggle, and screen transitions.
 */
public class LoginScreenController {

    @FXML
    private TextField usernameField;  // Input field for the username

    @FXML
    private PasswordField passwordField;  // Input field for the password (hidden)

    @FXML
    private TextField passwordFieldVisible;  // Input field for the password (visible)

    @FXML
    private Button togglePasswordVisibility;  // Button to toggle password visibility

    @FXML
    private ImageView eyeIcon;  // Icon to show/hide password

    @FXML
    private Button loginButton;  // Button to submit the login credentials

    @FXML
    private Label badMessageToUser;  // Label to show error messages when login fails
    
    @FXML
    private Button xButton;  // Button to close the application

    private boolean isPasswordVisible = false;  // Flag to track password visibility state

    /**
     * Initializes the controller after its root element has been completely processed.
     * Sets up the password visibility toggle, binds the visible and hidden password fields, 
     * and handles the Enter key event for the password field.
     */
    @FXML
    private void initialize() {
    	HBox.setMargin(usernameField, new Insets(0, 0, 0, 28));
        badMessageToUser.setVisible(false);

        passwordFieldVisible.textProperty().bindBidirectional(passwordField.textProperty());
        eyeIcon.setImage(new Image(getClass().getResourceAsStream("hide.png")));

        Platform.runLater(() -> {
            Stage stage = (Stage) usernameField.getScene().getWindow();
            stage.sizeToScene();
        });

        passwordField.setOnKeyPressed(event -> {
            switch (event.getCode()) {
                case ENTER:
                    handleLoginButtonAction();
                    break;
                default:
                    break;
            }
        });
    }

    /**
     * Toggles the visibility of the password field. Switches between displaying the password
     * as plain text and as hidden characters. Also changes the eye icon to indicate visibility status.
     */
    @FXML
    private void togglePasswordField() {
        isPasswordVisible = !isPasswordVisible;
        if (isPasswordVisible) {
            passwordField.setVisible(false);
            passwordField.setManaged(false);
            passwordFieldVisible.setVisible(true);
            passwordFieldVisible.setManaged(true);
            eyeIcon.setImage(new Image(getClass().getResourceAsStream("view.png"))); // עין עם קו חוצה
        } else {
            passwordField.setVisible(true);
            passwordField.setManaged(true);
            passwordFieldVisible.setVisible(false);
            passwordFieldVisible.setManaged(false);
            eyeIcon.setImage(new Image(getClass().getResourceAsStream("hide.png"))); // עין רגילה
        }
    }

    /**
     * Handles the action when the login button is clicked or when Enter is pressed.
     * Validates the username and password. If successful, transitions to the main screen.
     * If the credentials are incorrect, an error message is displayed.
     */
    @FXML
    private void handleLoginButtonAction() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if ((username.equals("doctor") && password.equals("801010")) || 
            (username.equals("developer") && password.equals("639237"))) {
            try {
                MainScreenController.setIsDeveloper(username.equals("developer"));
                FXMLLoader loader = new FXMLLoader(getClass().getResource("mainScreen.fxml"));
                Parent root = loader.load();

                Stage stage = (Stage) loginButton.getScene().getWindow();
                stage.close();

                Stage mainStage = new Stage();
                mainStage.setScene(new Scene(root));
                mainStage.setWidth(565);
                mainStage.setHeight(530);
                mainStage.show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            badMessageToUser.setVisible(true);
            badMessageToUser.setText("Invalid username or password. Please try again.");
        }
    }
    
    /**
     * Handles the action when the "X" button is clicked.
     * Displays a confirmation dialog and exits the application if confirmed by the user.
     */
    @FXML
    private void handleXAction() {

    	Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Exit Confirmation");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you want to exit?");

        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {

            	Platform.exit();
            }
        });
    }
    
}
