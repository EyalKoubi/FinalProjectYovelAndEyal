package gui;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Parent;

/**
 * Main application class for the Laryngoscopy Analysis Tool.
 * This class extends the JavaFX {@link Application} class and serves as the entry point
 * for the application.
 */
public class MainApp extends Application {

    /**
     * The start method is the main entry point for the JavaFX application.
     * It loads the initial FXML layout for the login screen and sets the stage.
     *
     * @param primaryStage the main stage (window) of the JavaFX application.
     * @throws Exception if there is an issue loading the FXML resource.
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("LoginScreen.fxml"));
        primaryStage.setTitle("Laryngoscopy Analysis Tool");
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }

    /**
     * The main method, which is the entry point to the JavaFX application.
     * It calls the {@code launch} method to start the JavaFX runtime.
     *
     * @param args command-line arguments passed to the application.
     */
    public static void main(String[] args) {
        launch(args);
    }
}
