// MainScreenController.java
package gui;

import java.io.File;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * Controller class for the main screen of the Laryngoscopy Analysis Tool.
 * Handles user interactions such as uploading videos, accessing developer settings,
 * and exiting the application.
 */
public class MainScreenController {

	@FXML
	private Button uploadVideoButton;  // Button to upload a video

	@FXML
	private Button developerSettingsButton;  // Button to access developer settings

	@FXML
	private Button exitButton;  // Button to exit the application
	
	@FXML
	private Label errorMessage;  // Label to display error messages

	private File selectedVideoFile;  // The video file selected by the user

	private static boolean isDeveloper;  // Flag to indicate if the current user is a developer

    /**
     * Sets the flag indicating if the current user is a developer.
     * 
     * @param boolVar the boolean value indicating developer status.
     */
	public static void setIsDeveloper(boolean boolVar) {
		isDeveloper = boolVar;
	}

    /**
     * Initializes the controller after the root element has been completely processed.
     * Sets the visibility of the developer settings button and hides the error message by default.
     */
	@FXML
	private void initialize() {
		developerSettingsButton.setVisible(isDeveloper);
		errorMessage.setVisible(false);
	}

    /**
     * Handles the action of the "Upload Video" button.
     * Opens a {@link FileChooser} dialog to select a video file and proceeds to the next screen
     * if a valid video is selected.
     */
	@FXML
	private void handleUploadVideoButtonAction() {
		// Create a FileChooser to allow the user to select a video file
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Upload Laryngoscopy Video");
		fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Video Files", "*.mp4"));

		// Open the file dialog
		Stage stage = (Stage) uploadVideoButton.getScene().getWindow();
		selectedVideoFile = fileChooser.showOpenDialog(stage);

		// Check if a file was selected
		if (selectedVideoFile != null) {
			System.out.println("Video file selected: " + selectedVideoFile.getAbsolutePath());
			
			if (selectedVideoFile.getName().toLowerCase().endsWith(".mp4")) {
				try {
					FXMLLoader loader = new FXMLLoader(getClass().getResource("VideoAnalysisScreen.fxml"));
					Parent root = loader.load();

					// Get the controller of the next screen
					VideoAnalysisScreenController controller = loader.getController();
					controller.setSelectedVideoFile(selectedVideoFile); // Pass the selected video file to the next screen

		            Stage stage1 = (Stage) exitButton.getScene().getWindow();
		            stage1.close();
		            Stage newStage = new Stage();
		            newStage.setScene(new Scene(root));
		            newStage.setWidth(595);
		            newStage.setHeight(530);
		            newStage.show();
				} catch (IOException e) {
					e.printStackTrace();
				}
				errorMessage.setVisible(false);
			}
			else
				errorMessage.setVisible(true);

		} else {
			System.out.println("Video file selection was canceled.");
		}
	}

    /**
     * Handles the action of the "Developer Settings" button.
     * Opens a password input dialog for developer access and handles the transition
     * if the correct password is entered.
     */
	@FXML
	private void handleDeveloperSettingsButtonAction() {
		try {

			FXMLLoader loader = new FXMLLoader(getClass().getResource("devPass.fxml"));
			Parent root = loader.load();

			Stage popupStage = new Stage();
			popupStage.setTitle("Enter Password");
			popupStage.initModality(Modality.APPLICATION_MODAL);
			popupStage.initStyle(StageStyle.UNDECORATED);

			Scene scene = new Scene(root);
			popupStage.setScene(scene);

			popupStage.setResizable(false);

			popupStage.showAndWait();

			Stage primaryStage = (Stage) developerSettingsButton.getScene().getWindow();
			primaryStage.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

    /**
     * Handles the action of the "Exit" button.
     * Returns the user to the login screen.
     */
	@FXML
	private void handleExitAction() {
		try {
			// Load the main screen FXML
			FXMLLoader loader = new FXMLLoader(getClass().getResource("LoginScreen.fxml"));
			Parent root = loader.load();
			exitButton.getScene().setRoot(root);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
