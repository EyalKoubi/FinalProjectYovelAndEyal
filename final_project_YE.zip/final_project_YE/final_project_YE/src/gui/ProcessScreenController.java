package gui;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import controllers.FrameAnalyzer;
import controllers.FrameProcessor;
import controllers.MotionEstimator;
import controllers.RegionSegmenter;
import controllers.TriangleDetector;
import controllers.VideoToFrames;
import entities.Frame;
import entities.VShape;
import entities.Video;

/**
 * Controller for the video processing screen in the Laryngoscopy Analysis Tool.
 * Handles video analysis, processing each frame to detect V-shape regions and calculate focus scores.
 * Displays progress of the video analysis and handles stopping and exiting the process.
 */
public class ProcessScreenController {
	
    @FXML
    private ProgressIndicator progressIndicator;  // Progress indicator for overall process

    @FXML
    private ImageView completeImageView;  // Image view to display completion status

    @FXML
    private ProgressBar progressBar;  // Progress bar for frame analysis

    @FXML
    private Label progressLabel;  // Label to show current progress

    @FXML
    private Button stopButton;  // Button to stop or continue the process

    @FXML
    private Button backButton;  // Button to return to the main screen

    private ExecutorService executorService;  // Thread pool for running the video analysis task
    private boolean stopProcess = false;  // Flag to indicate whether the process should be stopped
    private File selectedVideoFile;  // The selected video file

    private BufferedImage bestImage;  // Image of the frame with the best focus score
    private BufferedImage bestRightSideImage;  // Image of the right side segment with the best focus
    private BufferedImage bestLeftSideImage;  // Image of the left side segment with the best focus
    private BufferedImage bestBaseImage;  // Image of the base segment with the best focus

    /**
     * Sets the selected video file to be processed.
     * 
     * @param selectedVideoFile The video file selected by the user.
     */
    public void setSelectedVideoFile(File selectedVideoFile) {
        this.selectedVideoFile = selectedVideoFile;
    }

    /**
     * Initializes the process screen, setting up default images and UI components.
     * Displays an image of a turtle while processing, and configures the progress indicators.
     */
    @FXML
    private void initialize() {
        Image completeImage = new Image(getClass().getResourceAsStream("turtle.png"));
        completeImageView.setImage(completeImage);
        progressIndicator.setVisible(true);
        completeImageView.setVisible(false);
        progressBar.setVisible(false);
        stopButton.setVisible(false);
        progressLabel.setText("Wait, we still divide the video to frames...");
        executorService = Executors.newSingleThreadExecutor();
    }

    /**
     * Starts the process of analyzing the video, which involves dividing the video into frames,
     * analyzing each frame for V-shapes, and calculating focus scores.
     * This runs in a separate thread to keep the UI responsive.
     */
    public void startProcess() {
        executorService.submit(() -> {
            try {
                String intermediateDir = "C:\\vids\\intermediate";
                String triangleDetectedDir = "C:\\vids\\TriangleDetectedFrames";
                String rightSideDir = "C:\\vids\\right_side_of_triangle";
                String leftSideDir = "C:\\vids\\left_side_of_triangle";
                String baseDir = "C:\\vids\\base_of_triangle";
                String focusOutputDir = "C:\\vids\\MostFocusedFrame";

                FrameAnalyzer.createDirectoryIfNotExists(intermediateDir);
                FrameAnalyzer.createDirectoryIfNotExists(triangleDetectedDir);
                FrameAnalyzer.createDirectoryIfNotExists(rightSideDir);
                FrameAnalyzer.createDirectoryIfNotExists(leftSideDir);
                FrameAnalyzer.createDirectoryIfNotExists(baseDir);
                FrameAnalyzer.createDirectoryIfNotExists(focusOutputDir);
                Video video = new Video(selectedVideoFile.getAbsolutePath(), null, 30, 0);
                List<Frame> frames = VideoToFrames.divideIntoFrames(video);

                if (frames == null || frames.isEmpty()) {
                    Platform.runLater(() -> progressLabel.setText("No frames extracted from video."));
                    return;
                }

                int frameCount = frames.size();
                double progress = 0;
                double increment = 1.0 / frameCount;

                FrameProcessor frameProcessor = new FrameProcessor();
                TriangleDetector triangleDetector = new TriangleDetector(SettingsScreenController.getLeastSquaresThreshold(), 0.3, 1);
                MotionEstimator motionEstimator = new MotionEstimator(55.0);
                FrameAnalyzer focusAnalyzer = new FrameAnalyzer(120.0);

                double bestGeneralFocusScore = 0;
                double bestSidesFocusScore = 0;
                double bestBaseFocusScore = 0;
                progressIndicator.setVisible(false);
                progressBar.setVisible(true);
                progressBar.setProgress(0);
                progressLabel.setText("0%");
                for (int i = 0; i < frameCount && !stopProcess; i++) {
                    Frame frame = frames.get(i);

                    int[] histogram = frameProcessor.calculateHistogram(frame);
                    int otsuThreshold = frameProcessor.calculateOtsuThreshold(histogram);

                    RegionSegmenter regionSegmenter = new RegionSegmenter(SettingsScreenController.getSegmentationThreshold(), SettingsScreenController.getJumpPixels());
                    List<int[][]> segmentedRegions = regionSegmenter.segmentRegions(frame, otsuThreshold);

                    int regionIndex = 0;
                    for (int[][] segmentedRegion : segmentedRegions) {
                        if (TriangleDetector.hasPotentialForThroatOpening(segmentedRegion)) {
                            regionIndex++;

                            VShape vShape = triangleDetector.detectBestVShape(segmentedRegion, frame.getFrameNumber(), regionIndex);
                            if (vShape != null) {
                                BufferedImage frameImage = FrameAnalyzer.deepCopyBufferedImage(frame.getBufferedImage());
                                TriangleDetector.drawTriangle(frameImage, vShape);

                                int consistentFrameIndex = i + 1;
                                while (consistentFrameIndex < frameCount && motionEstimator.areFramesSimilar(frame, frames.get(consistentFrameIndex), vShape)) {
                                    consistentFrameIndex++;
                                }
                                
                                BufferedImage originalRGBImage = FrameAnalyzer.getOriginalRGBImage(frame.getFrameNumber());

                                bestRightSideImage = focusAnalyzer.extractRightSideSegment(originalRGBImage, vShape);
                                bestLeftSideImage = focusAnalyzer.extractLeftSideSegment(originalRGBImage, vShape);
                                bestBaseImage = focusAnalyzer.extractBaseSegment(originalRGBImage, vShape);

                                focusAnalyzer.evaluateQuality(frame);
                                double generalFocusScore = frame.getGeneralFocusScore();
                                double sidesFocusScore = frame.getSidesFocusScore();
                                double baseFocusScore = frame.getBaseFocusScore();

                                if (generalFocusScore > bestGeneralFocusScore) {
                                    bestGeneralFocusScore = generalFocusScore;
                                    bestImage = originalRGBImage;
                                }
                                if (sidesFocusScore > bestSidesFocusScore) {
                                    bestSidesFocusScore = sidesFocusScore;
                                }
                                if (baseFocusScore > bestBaseFocusScore) {
                                    bestBaseFocusScore = baseFocusScore;
                                }
                            }
                        }
                    }

                    progress += increment;
                    final double currentProgress = progress;

                    Platform.runLater(() -> {
                        progressBar.setProgress(currentProgress);
                        progressLabel.setText(String.format("%.0f%%", currentProgress * 100));
                    });
                }

                if (!stopProcess) {
                    progressIndicator.setVisible(false);
                    completeImageView.setVisible(true);
                    Platform.runLater(() -> progressLabel.setText("Completed!"));
                    Platform.runLater(() -> {
                    	stopButton.setVisible(true);
                    	stopButton.setText("Continue");
                    });
                    
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        });

    }

    /**
     * Handles the action of the stop button, transitioning to the analysis result screen.
     * Passes the best images to the {@link ResultScreenController} for further display.
     */
    @FXML
    private void handleStopButtonAction() {
        try {
        	
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AnalysisResultScreen.fxml"));
            Parent root = loader.load();
            ResultScreenController resultController = loader.getController();

            resultController.setBestImages(bestImage, bestRightSideImage, bestLeftSideImage, bestBaseImage);

            backButton.getScene().setRoot(root);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Handles the action of the back button, stopping the current process and returning
     * to the main screen.
     */
    @FXML
    private void handleBackButtonAction() {
        stopProcess = true;
        executorService.shutdownNow();

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("mainScreen.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.close();
            Stage newStage = new Stage();
            newStage.setScene(new Scene(root));
            newStage.setWidth(565);
            newStage.setHeight(530);
            newStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
