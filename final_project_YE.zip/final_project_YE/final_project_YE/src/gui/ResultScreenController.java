package gui;

import javafx.embed.swing.SwingFXUtils;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.imageio.ImageIO;

/**
 * The ResultScreenController class is responsible for controlling the result
 * screen in the application. It allows users to view and save the best images
 * generated from the endoscopy video, including the best general view, right side
 * view, left side view, and base view. The user can also navigate back to the main
 * screen.
 */
public class ResultScreenController {

    @FXML
    private Button backButton;

    @FXML
    private Button saveImageButton;

    @FXML
    private Button showBestRightSideButton;

    @FXML
    private Button showBestLeftSideButton;

    @FXML
    private Button showBestBaseButton;

    @FXML
    private Button showBestGeneralButton;

    @FXML
    private ImageView resultImageView;

    @FXML
    private Label resultText;

    private Image bestImage;
    private Image bestRightSideImage;
    private Image bestLeftSideImage;
    private Image bestBaseImage;

    /**
     * Initializes the controller class. This method is automatically called
     * after the FXML file has been loaded.
     */
    @FXML
    private void initialize() {
    	
    }

    /**
     * Sets the best images from the video analysis to be displayed on the result screen.
     * 
     * @param bestGeneralImage the best general view image
     * @param bestRightSideImage the best right side view image
     * @param bestLeftSideImage the best left side view image
     * @param bestBaseImage the best base view image
     */
    public void setBestImages(BufferedImage bestGeneralImage, BufferedImage bestRightSideImage,
                              BufferedImage bestLeftSideImage, BufferedImage bestBaseImage) {

    	this.bestImage = SwingFXUtils.toFXImage(bestGeneralImage, null);
    	this.bestRightSideImage = SwingFXUtils.toFXImage(bestRightSideImage, null);
    	this.bestLeftSideImage = SwingFXUtils.toFXImage(bestLeftSideImage, null);
    	this.bestBaseImage = SwingFXUtils.toFXImage(bestBaseImage, null);

    	resultImageView.setImage(this.bestImage);
        resultText.setText("The image shown is the highest quality image from the endoscopy video :)");
    }

    /**
     * Handles the action of saving the currently displayed image to the user's device.
     * Opens a file chooser dialog to select the destination and file format.
     */
    @FXML
    private void handleSaveImageAction() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Image");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"));
        File file = fileChooser.showSaveDialog(new Stage());

        if (file != null) {
            try (FileOutputStream out = new FileOutputStream(file)) {
                ImageIO.write(SwingFXUtils.fromFXImage(resultImageView.getImage(), null), "png", out);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Displays the best right side view image in the ImageView.
     */
    @FXML
    private void handleShowBestRightSideViewAction() {
        if (bestRightSideImage != null) {
            resultImageView.setImage(bestRightSideImage);
            resultText.setText("Showing the best right side view from the endoscopy video :)");
        }
    }

    /**
     * Displays the best left side view image in the ImageView.
     */
    @FXML
    private void handleShowBestLeftSideViewAction() {
        if (bestLeftSideImage != null) {
            resultImageView.setImage(bestLeftSideImage);
            resultText.setText("Showing the best left side view from the endoscopy video :)");
        }
    }

    /**
     * Displays the best base view image in the ImageView.
     */
    @FXML
    private void handleShowBestBaseViewAction() {
        if (bestBaseImage != null) {
            resultImageView.setImage(bestBaseImage);
            resultText.setText("Showing the best base view from the endoscopy video :)");
        }
    }

    /**
     * Displays the best general view image in the ImageView.
     */
    @FXML
    private void handleShowBestGeneralViewAction() {
        if (bestImage != null) {
            resultImageView.setImage(bestImage);
            resultText.setText("Showing the best general view from the endoscopy video :)");
        }
    }

    /**
     * Handles the action of navigating back to the main screen. Loads the
     * main screen FXML and switches the scene.
     */
    @FXML
    private void handleBackButtonAction() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("mainScreen.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.close();
            Stage newStage = new Stage();
            newStage.setScene(new Scene(root));
            newStage.setWidth(565);
            newStage.setHeight(530);
            newStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
