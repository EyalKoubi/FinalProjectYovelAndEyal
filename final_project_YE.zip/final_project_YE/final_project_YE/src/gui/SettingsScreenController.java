package gui;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.TextField;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import java.io.IOException;

/**
 * The SettingsScreenController class handles the functionality for the settings screen
 * of the application. Users can adjust various threshold settings and return to the main
 * screen. The changes are saved, and feedback is provided for successful or invalid input.
 */
public class SettingsScreenController {

    @FXML
    private TextField segmentationThresholdField;

    @FXML
    private TextField jumpPixelField;

    @FXML
    private TextField pointsInGroupField;

    @FXML
    private TextField leastSquaresThresholdField;

    @FXML
    private Button saveChangesButton;

    @FXML
    private Button backButton;
    
    @FXML
    private Label goodMessageToUser;
    
    @FXML
    private Label badMessageToUser;

    private static double segmentationThreshold = 0.5758;
    private static int jumpPixels = 1;
    private static int pointsInGroup = 1;
    private static double leastSquaresThreshold = 3.0;

    /**
     * Initializes the controller. This method is automatically called after the FXML
     * file has been loaded. It sets the initial values for the fields and attaches
     * event listeners to handle "Enter" key press for saving changes.
     */
    @FXML
    private void initialize() {
    	
        // Set text fields to the current values
        segmentationThresholdField.setText(String.valueOf(segmentationThreshold));
        jumpPixelField.setText(String.valueOf(jumpPixels));
        pointsInGroupField.setText(String.valueOf(pointsInGroup));
        leastSquaresThresholdField.setText(String.valueOf(leastSquaresThreshold));
        goodMessageToUser.setVisible(false);
        badMessageToUser.setVisible(false);
        goodMessageToUser.setText("Settings saved successfully!");
        badMessageToUser.setText("Invalid input!");
        segmentationThresholdField.setOnKeyPressed(event -> {
            switch (event.getCode()) {
            case ENTER:
            	handleSaveChangesButtonAction();
                break;
            default:
                break;
            }
        });
        jumpPixelField.setOnKeyPressed(event -> {
            switch (event.getCode()) {
            case ENTER:
            	handleSaveChangesButtonAction();
                break;
            default:
                break;
            }
        });
        pointsInGroupField.setOnKeyPressed(event -> {
            switch (event.getCode()) {
            case ENTER:
            	handleSaveChangesButtonAction();
                break;
            default:
                break;
            }
        });
        leastSquaresThresholdField.setOnKeyPressed(event -> {
            switch (event.getCode()) {
            case ENTER:
            	handleSaveChangesButtonAction();
                break;
            default:
                break;
            }
        });
    }

    /**
     * Handles the save button action, which attempts to save the values entered
     * in the text fields. If the input values are invalid, an error message is displayed.
     * Otherwise, the settings are saved and a success message is shown.
     */
    @FXML
    private void handleSaveChangesButtonAction() {
        try {
            // Parse the input values from text fields
            segmentationThreshold = Double.parseDouble(segmentationThresholdField.getText());
            jumpPixels = Integer.parseInt(jumpPixelField.getText());
            pointsInGroup = Integer.parseInt(pointsInGroupField.getText());
            leastSquaresThreshold = Double.parseDouble(leastSquaresThresholdField.getText());
            
            // Provide feedback to the user, e.g., display a success message
            System.out.println("Settings saved successfully.");
            badMessageToUser.setVisible(false);
            goodMessageToUser.setVisible(true);

        } catch (NumberFormatException e) {
        	goodMessageToUser.setVisible(false);
        	badMessageToUser.setVisible(true);
            // Handle invalid input, such as non-numeric values
            System.err.println("Invalid input: Please ensure all fields are filled with valid numbers.");
        }
    }

    /**
     * Handles the back button action, which navigates the user back to the main screen.
     * It loads the main screen FXML and switches the scene.
     */
    @FXML
    private void handleBackButtonAction() {
        // Logic to go back to the main screen
        try {
            // Load the main screen FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("mainScreen.fxml"));
            Parent root = loader.load();
            backButton.getScene().setRoot(root);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Gets the jump pixel value used in segmentation.
     * 
     * @return the number of pixels to jump during segmentation.
     */
	public static int getJumpPixels() {
		return jumpPixels;
	}

    /**
     * Gets the least squares threshold value used in triangle detection.
     * 
     * @return the least squares threshold value.
     */
	public static double getLeastSquaresThreshold() {
		return leastSquaresThreshold;
	}

    /**
     * Gets the segmentation threshold value used to segment regions in the frames.
     * 
     * @return the segmentation threshold value.
     */
	public static double getSegmentationThreshold() {
		return segmentationThreshold;
	}
    
}
