// VideoAnalysisScreenController.java
package gui;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;

/**
 * The VideoAnalysisScreenController class handles the functionality of the video analysis screen.
 * It allows users to display the selected video, control video playback, and start the process of frame selection.
 */
public class VideoAnalysisScreenController {

	@FXML
    private Button displayVideoButton;

    @FXML
    private Button startFramesSelectionButton;

    @FXML
    private Button backButton;

    @FXML
    private MediaView mediaView;

    @FXML
    private ImageView staticImageView;
    
    @FXML
    private ImageView stopAndPlayView;

    @FXML
    private Button exitVideoButton;

    @FXML
    private Button stopButton;

    @FXML
    private Button replayButton;

    private File selectedVideoFile;
    private MediaPlayer mediaPlayer;
    private boolean isStopped;

    /**
     * Sets the selected video file to be analyzed.
     * 
     * @param selectedVideoFile the video file selected by the user
     */
    public void setSelectedVideoFile(File selectedVideoFile) {
        this.selectedVideoFile = selectedVideoFile;
    }
    
    /**
     * Sets the video stop status.
     * 
     * @param boolVar boolean flag indicating if the video is stopped
     */
    private void setIsStopped(boolean boolVar) {
    	this.isStopped = boolVar;
    }

    /**
     * Initializes the screen components. This method is automatically called after the FXML
     * file has been loaded. Sets up the initial visibility of components and loads the stop icon.
     */
    @FXML
    private void initialize() {
        mediaView.setVisible(false);
        staticImageView.setVisible(true);
        exitVideoButton.setVisible(false);
        stopButton.setVisible(false);
        replayButton.setVisible(false);
        setIsStopped(false);
        stopAndPlayView.setImage(new Image(getClass().getResourceAsStream("stop.png")));
    }
    
    /**
     * Handles the action of starting the frame selection process. 
     * Loads the process screen and passes the selected video file to the ProcessScreenController.
     */
	@FXML
	private void handleStartFramesSelectionButtonAction() {
	    if (selectedVideoFile != null) {
	        try {
	            // Load the process screen FXML
	            FXMLLoader loader = new FXMLLoader(getClass().getResource("processScreen.fxml"));
	            Parent root = loader.load();

	            // Pass the selected video file to the ProcessScreenController
	            ProcessScreenController processController = loader.getController();
	            processController.setSelectedVideoFile(selectedVideoFile);
	            processController.startProcess();

	            Stage stage = (Stage) backButton.getScene().getWindow();
	            stage.close();
	            Stage newStage = new Stage();
	            newStage.setScene(new Scene(root));
	            newStage.setWidth(580);
	            newStage.setHeight(500);
	            newStage.show();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    } else {
	        System.out.println("No video file selected.");
	    }
	}

    /**
     * Handles the action of returning to the main screen.
     * Loads the main screen FXML and switches the scene.
     */
	@FXML
	private void handleBackButtonAction() {
	    try {
	        FXMLLoader loader = new FXMLLoader(getClass().getResource("mainScreen.fxml"));
	        Parent root = loader.load();
            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.close();
            Stage newStage = new Stage();
            newStage.setScene(new Scene(root));
            newStage.setWidth(565);
            newStage.setHeight(530);
            newStage.show();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
    
    /**
     * Handles the action of displaying the selected video in the MediaView component.
     * Initializes and plays the video using MediaPlayer.
     */
	@FXML
    private void handleDisplayVideoButtonAction() {
        if (selectedVideoFile != null) {
            try {
                Media media = new Media(selectedVideoFile.toURI().toString());
                mediaPlayer = new MediaPlayer(media);
                mediaView.setMediaPlayer(mediaPlayer);

                mediaView.setVisible(true);
                exitVideoButton.setVisible(true);
                stopButton.setVisible(true);
                replayButton.setVisible(true);

                mediaPlayer.play();

            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("Error displaying video: " + e.getMessage());
            }
        } else {
            System.out.println("No video file selected.");
        }
    }
	
    /**
     * Handles the action of stopping or resuming the video playback.
     * Toggles between pause and play based on the current stop status.
     */
	@FXML
    private void handleStopButtonAction() {
        if (mediaPlayer != null) {
        	if (isStopped) {
        		stopAndPlayView.setImage(new Image(getClass().getResourceAsStream("stop.png")));
        		mediaPlayer.play();
        	}
        	else {
        		stopAndPlayView.setImage(new Image(getClass().getResourceAsStream("play.png")));
        		mediaPlayer.pause();
        	}
        	setIsStopped(!isStopped);
        }
    }
	
    /**
     * Handles the action of replaying the video from the beginning.
     * Stops and seeks to the start time of the video and plays it again.
     */
	@FXML
    private void handleReplayButtonAction() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.seek(mediaPlayer.getStartTime());
            mediaPlayer.play();
        }
    }
	
    /**
     * Handles the action of exiting the video playback mode.
     * Stops the video and hides the MediaView, displaying the static image instead.
     */
	@FXML
    private void handleExitVideoButtonAction() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
        }
        mediaView.setVisible(false);
        staticImageView.setVisible(true);
        exitVideoButton.setVisible(false);
        stopButton.setVisible(false);
        replayButton.setVisible(false);
    }

}